#pragma once

#include <string>
#include <vector>
#include "../sdk/scpsl.h"

// Global object lists used by the schematic exporter (as in the original snippet).
extern std::vector<PrimitiveObjectToy*> primitivesls;
extern std::vector<Object*> Lights;
extern std::vector<void*> Pickups;

namespace SchematicDumper
{
    // File name entered in the menu (no extension).
    extern char Filename[128];

    // Status / result message shown in the menu.
    extern std::string LastStatus;

    // Last scan counts.
    extern int LastPrimitiveCount;
    extern int LastLightCount;

    // Category toggles (menu checkboxes). Disabled categories are neither
    // collected nor exported. All enabled by default.
    extern bool CollectPrimitives;
    extern bool CollectLights;
    extern bool CollectTexts;
    extern bool CollectPickups;

    // Scans the current world and writes Desktop\SCPSL_Schematics\<name>.json.
    // Returns a short status message.
    std::string Run(const std::string& fileName);

    // Progressive (incremental) capture: keeps appending newly-spawned blocks
    // while the player walks over a hidden-optimisation server.
    extern bool Collecting;
    void StartCollection();
    std::string Stop(const std::string& fileName);
    void Tick(); // call every frame from the render hook while Collecting
}
