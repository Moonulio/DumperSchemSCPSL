#pragma once

namespace DX11Hook
{
    // Creates a dummy swapchain and swaps the Present/ResizeBuffers vtable
    // slots. Call once D3D11 is up. Returns false until the swapchain is ready.
    bool Initialize();

    // Requests full unload from the game: restores the vtable/WndProc hooks,
    // shuts ImGui down and unloads the DLL (in a separate thread). Returns
    // immediately; the DLL is freed a short moment later.
    void RequestUnload();
}
