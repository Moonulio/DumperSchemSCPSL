#include "file.h"
#include <windows.h>
#include <shlobj.h>
#include <cstdio>

namespace
{
    std::string WideToUtf8(const wchar_t* w)
    {
        if (!w) return {};
        int size = WideCharToMultiByte(CP_UTF8, 0, w, -1, nullptr, 0, nullptr, nullptr);
        if (size <= 0) return {};
        std::string out((size_t)size, '\0');
        WideCharToMultiByte(CP_UTF8, 0, w, -1, &out[0], size, nullptr, nullptr);
        if (!out.empty() && out.back() == '\0')
            out.pop_back();
        return out;
    }
}

namespace FileUtils
{
    std::string GetDesktopPath()
    {
        PWSTR raw = nullptr;
        if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_Desktop, KF_FLAG_CREATE, nullptr, &raw))) {
            std::string path = WideToUtf8(raw);
            CoTaskMemFree(raw);
            return path;
        }
        // Fallback
        const char* profile = getenv("USERPROFILE");
        if (profile) {
            std::string p(profile);
            return p + "\\Desktop";
        }
        return {};
    }

    std::string CreateFolder(const std::string& path)
    {
        if (path.empty()) return {};
        std::string cur;
        size_t start = 0;
        while (start <= path.size()) {
            size_t pos = path.find_first_of("\\/", start);
            std::string part = path.substr(start, pos == std::string::npos ? path.size() - start : pos - start);
            if (!part.empty()) {
                if (part.size() == 2 && part[1] == ':') {
                    cur = part; // drive letter, skip
                } else {
                    if (!cur.empty() && cur.back() != '\\')
                        cur += '\\';
                    cur += part;
                    CreateDirectoryA(cur.c_str(), nullptr);
                }
            }
            if (pos == std::string::npos) break;
            start = pos + 1;
        }
        return path;
    }

    std::string SanitizeFileName(const std::string& name)
    {
        std::string out;
        out.reserve(name.size());
        for (char c : name) {
            switch (c) {
                case '<': case '>': case ':': case '"':
                case '/': case '\\': case '|': case '?': case '*':
                    break;
                case ' ': case '\t': case '\r': case '\n':
                    out += '_';
                    break;
                default:
                    out += c;
            }
        }
        return out;
    }

    bool WriteTextFile(const std::string& path, const std::string& content)
    {
        FILE* f = nullptr;
        if (fopen_s(&f, path.c_str(), "wb") != 0 || !f)
            return false;
        size_t written = fwrite(content.data(), 1, content.size(), f);
        fclose(f);
        return written == content.size();
    }
}
