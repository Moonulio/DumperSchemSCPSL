@echo off
setlocal
set "FOLDER=C:\Users\User\Desktop\Free\SCPSL-Schematic-Dumper"

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator rights...
    powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo Adding Windows Defender exclusion: %FOLDER%
powershell -NoProfile -Command "Add-MpPreference -ExclusionPath '%FOLDER%'"
echo.
echo Done. Now rebuild the injector (or just tell the assistant).
pause
