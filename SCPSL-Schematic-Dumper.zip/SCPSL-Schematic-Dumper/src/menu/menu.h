#pragma once

namespace Menu
{
    extern bool Opened;

    void Render();
    void Toggle();
}
