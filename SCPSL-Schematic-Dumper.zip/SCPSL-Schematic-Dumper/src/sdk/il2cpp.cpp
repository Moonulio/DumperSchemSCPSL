#include "il2cpp.h"
#include <string>
#include <vector>

Il2CppDomain* domain = nullptr;

namespace API
{
    namespace
    {
        template <typename T>
        bool Resolve(const char* name, T& out) {
            out = (T)GetProcAddress(gameAssembly, name);
            return out != nullptr;
        }
    }

    bool Initialize()
    {
        gameAssembly = GetModuleHandleW(L"GameAssembly.dll");
        if (!gameAssembly) return false;

        // Core exports: without these the mod cannot work.
        bool ok = true;
        ok &= Resolve("il2cpp_domain_get",                il2cpp_domain_get);
        ok &= Resolve("il2cpp_thread_attach",             il2cpp_thread_attach);
        ok &= Resolve("il2cpp_domain_get_assemblies",     il2cpp_domain_get_assemblies);
        ok &= Resolve("il2cpp_assembly_get_image",        il2cpp_assembly_get_image);
        ok &= Resolve("il2cpp_image_get_name",            il2cpp_image_get_name);
        ok &= Resolve("il2cpp_class_from_name",           il2cpp_class_from_name);
        ok &= Resolve("il2cpp_class_get_method_from_name",il2cpp_class_get_method_from_name);
        ok &= Resolve("il2cpp_runtime_invoke",            il2cpp_runtime_invoke);
        ok &= Resolve("il2cpp_object_unbox",              il2cpp_object_unbox);
        ok &= Resolve("il2cpp_object_get_class",          il2cpp_object_get_class);
        ok &= Resolve("il2cpp_class_get_name",            il2cpp_class_get_name);
        ok &= Resolve("il2cpp_class_get_parent",          il2cpp_class_get_parent);
        ok &= Resolve("il2cpp_class_get_field_from_name", il2cpp_class_get_field_from_name);
        ok &= Resolve("il2cpp_field_get_name",            il2cpp_field_get_name);
        ok &= Resolve("il2cpp_field_get_offset",          il2cpp_field_get_offset);
        ok &= Resolve("il2cpp_field_get_value",           il2cpp_field_get_value);
        ok &= Resolve("il2cpp_field_static_get_value",    il2cpp_field_static_get_value);

        if (!ok) return false;

        // Optional exports: their absence only disables the matching fallback.
        Resolve("il2cpp_object_new",                il2cpp_object_new);
        Resolve("il2cpp_class_get_type",            il2cpp_class_get_type);
        Resolve("il2cpp_type_get_object",           il2cpp_type_get_object);
        Resolve("il2cpp_class_get_namespace",       il2cpp_class_get_namespace);
        Resolve("il2cpp_field_get_type",            il2cpp_field_get_type);
        Resolve("il2cpp_class_from_type",           il2cpp_class_from_type);
        Resolve("il2cpp_array_class_get",           il2cpp_array_class_get);
        Resolve("il2cpp_class_get_size",            il2cpp_class_get_size);
        Resolve("il2cpp_string_new",                il2cpp_string_new);
        Resolve("il2cpp_image_get_class_count",     il2cpp_image_get_class_count);
        Resolve("il2cpp_image_get_class",           il2cpp_image_get_class);
        Resolve("il2cpp_class_get_fields",          il2cpp_class_get_fields);
        Resolve("il2cpp_class_is_valuetype",        il2cpp_class_is_valuetype);

        if (domain == nullptr && il2cpp_domain_get)
            domain = il2cpp_domain_get();

        return domain != nullptr;
    }

    Il2CppImage* FindImage(const char* assemblyName)
    {
        if (!domain || !il2cpp_domain_get_assemblies || !il2cpp_assembly_get_image || !il2cpp_image_get_name)
            return nullptr;

        std::string wanted = assemblyName;
        size_t count = 0;
        const Il2CppAssembly** assemblies = il2cpp_domain_get_assemblies(domain, &count);
        for (size_t i = 0; i < count; i++) {
            if (!assemblies[i]) continue;
            Il2CppImage* img = il2cpp_assembly_get_image(assemblies[i]);
            if (!img) continue;
            const char* n = il2cpp_image_get_name(img);
            if (!n) continue;
            if (strcmp(n, wanted.c_str()) == 0)
                return img;
            // Accept the ".dll" suffixed variant.
            std::string n2 = n;
            if (n2.size() >= 4 && n2.compare(n2.size() - 4, 4, ".dll") == 0)
                n2.resize(n2.size() - 4);
            if (n2 == wanted)
                return img;
        }
        return nullptr;
    }

    Il2CppClass* FindClass(const char* assemblyName, const char* ns, const char* name)
    {
        if (!il2cpp_class_from_name) return nullptr;
        Il2CppImage* img = FindImage(assemblyName);
        if (!img) return nullptr;
        return il2cpp_class_from_name(img, ns, name);
    }

    const MethodInfo* FindMethod(Il2CppClass* klass, const char* name, int argc, bool searchParents)
    {
        if (!il2cpp_class_get_method_from_name) return nullptr;
        for (Il2CppClass* k = klass; k; k = searchParents ? il2cpp_class_get_parent(k) : nullptr) {
            const MethodInfo* m = il2cpp_class_get_method_from_name(k, name, argc);
            if (m) return m;
            if (!searchParents) break;
        }
        return nullptr;
    }

    Il2CppField* FindField(Il2CppClass* klass, const char* name)
    {
        if (!il2cpp_class_get_field_from_name) return nullptr;
        for (Il2CppClass* k = klass; k; k = il2cpp_class_get_parent(k)) {
            Il2CppField* f = il2cpp_class_get_field_from_name(k, name);
            if (f) return f;
        }
        return nullptr;
    }

    int32_t FindFieldOffset(Il2CppClass* klass, const char* name)
    {
        Il2CppField* f = FindField(klass, name);
        if (!f || !il2cpp_field_get_offset) return -1;
        return (int32_t)il2cpp_field_get_offset(f);
    }
}
