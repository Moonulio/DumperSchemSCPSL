#include "scpsl.h"
#include <vector>
#include <cmath>

namespace SCPSL
{
    Il2CppClass* PrimitiveObjectToy_Class = nullptr;
    Il2CppClass* LightSourceToy_Class     = nullptr;
    Il2CppClass* TextToy_Class            = nullptr;
    Il2CppClass* AdminToyBase_Class       = nullptr;
    Il2CppClass* MapEditor_Class          = nullptr;
    Il2CppClass* Object_Class             = nullptr;
    Il2CppClass* Renderer_Class           = nullptr;
    Il2CppClass* Material_Class           = nullptr;
    Il2CppClass* Transform_Class          = nullptr;
    Il2CppClass* Component_Class          = nullptr;
    Il2CppClass* Light_Class              = nullptr;
    Il2CppClass* TextMesh_Class           = nullptr;
    Il2CppClass* Application_Class        = nullptr;
    Il2CppClass* Cursor_Class             = nullptr;
    Il2CppClass* ItemPickupBase_Class     = nullptr;
    Il2CppClass* PickupSyncInfo_Class     = nullptr;
    Il2CppClass* FirearmPickup_Class      = nullptr;
}

namespace
{
    using namespace SCPSL;

    void* InvokeMethod(Il2CppClass* klass, void* obj, const char* name, int argc, void** params = nullptr, void** exc = nullptr)
    {
        const MethodInfo* m = API::FindMethod(klass, name, argc, true);
        if (!m) return nullptr;
        void* ex = nullptr;
        void* r = API::il2cpp_runtime_invoke(m, obj, params, &ex);
        if (exc) *exc = ex;
        return r;
    }

    // Invokes a method that returns a value type (struct/primitive).
    // il2cpp_runtime_invoke returns a *boxed* object for value types, so the
    // result must be unboxed before reading the raw bytes.
    template <typename T>
    bool InvokeValue(Il2CppClass* klass, void* obj, const char* name, T& out)
    {
        void* r = InvokeMethod(klass, obj, name, 0);
        if (!r) return false;
        if (API::il2cpp_object_unbox)
            out = *(T*)API::il2cpp_object_unbox((Il2CppObject*)r);
        else
            out = *(T*)r;
        return true;
    }

    bool IsInstanceOf(void* obj, Il2CppClass* klass)
    {
        if (!obj || !klass || !API::il2cpp_object_get_class || !API::il2cpp_class_get_parent) return false;
        for (Il2CppClass* k = API::il2cpp_object_get_class((Il2CppObject*)obj); k; k = API::il2cpp_class_get_parent(k))
            if (k == klass) return true;
        return false;
    }

    std::vector<void*> IterateList(void* listObj)
    {
        std::vector<void*> out;
        if (!listObj || !API::il2cpp_object_get_class) return out;
        Il2CppClass* listClass = API::il2cpp_object_get_class((Il2CppObject*)listObj);
        Il2CppField* itemsField = API::FindField(listClass, "_items");
        Il2CppField* sizeField  = API::FindField(listClass, "_size");
        if (!itemsField || !sizeField || !API::il2cpp_field_get_value) return out;

        void* items = nullptr;
        int   size  = 0;
        API::il2cpp_field_get_value((Il2CppObject*)listObj, itemsField, &items);
        API::il2cpp_field_get_value((Il2CppObject*)listObj, sizeField, &size);
        if (!items || size <= 0) return out;

        auto arr = (Il2CppArray*)items;
        for (int i = 0; i < size && (uint64_t)i < arr->max_length; i++) {
            void** p = ArrayElement<void*>(arr, (uint64_t)i);
            if (p && *p) out.push_back(*p);
        }
        return out;
    }

    std::vector<void*> FindObjectsOfTypeFallback(Il2CppClass* klass)
    {
        std::vector<void*> out;
        if (!klass || !Object_Class || !API::il2cpp_class_get_type || !API::il2cpp_type_get_object)
            return out;

        void* typeObj = API::il2cpp_type_get_object(API::il2cpp_class_get_type(klass));
        if (!typeObj) return out;

        void* exc = nullptr;
        void* params[1] = { typeObj };
        void* arr = InvokeMethod(Object_Class, nullptr, "FindObjectsOfType", 1, params, &exc);
        if (!arr) return out;

        auto a = (Il2CppArray*)arr;
        for (uint64_t i = 0; i < a->max_length; i++) {
            void** p = ArrayElement<void*>(a, i);
            if (p && *p) out.push_back(*p);
        }
        return out;
    }

    std::vector<void*> FindAllOfClass(Il2CppClass* klass)
    {
        if (!klass) return {};

        // Primary source: MapEditor.Objects (the live schematic object list).
        if (MapEditor_Class) {
            void* list = API::ReadStaticField<void*>(MapEditor_Class, "Objects", nullptr);
            if (list) {
                std::vector<void*> out;
                for (void* o : IterateList(list))
                    if (IsInstanceOf(o, klass)) out.push_back(o);
                return out;
            }
        }

        // Fallback: Unity Object.FindObjectsOfType(Type).
        return FindObjectsOfTypeFallback(klass);
    }

    bool ReadFieldVec(Il2CppClass* klass, void* obj, const char* name, Vector3& out)
    {
        int32_t off = API::FindFieldOffset(klass, name);
        if (off < 0 || !obj) return false;
        out = *(Vector3*)((uint8_t*)obj + off);
        return true;
    }

    std::string Utf16ToUtf8(const wchar_t* w, int len);

    // Reads a System.String instance field (field value is an Il2CppString*).
    std::string ReadStringField(Il2CppClass* klass, void* obj, const char* name)
    {
        void* s = API::ReadInstanceField<void*>(klass, obj, name, nullptr);
        if (!s) return {};
        auto str = (Il2CppString*)s;
        if (!str->chars || str->length <= 0) return {};
        return Utf16ToUtf8(str->chars, str->length);
    }

    // Reads a Vector2/Vector3-valued field by name (il2cpp stores them inline).
    template <typename T>
    bool ReadFieldValue(Il2CppClass* klass, void* obj, const char* name, T& out)
    {
        int32_t off = API::FindFieldOffset(klass, name);
        if (off < 0 || !obj) return false;
        out = *(T*)((uint8_t*)obj + off);
        return true;
    }

    bool ReadTransformVec(void* tr, const char* getter, Vector3& out)
    {
        return InvokeValue(Transform_Class, tr, getter, out);
    }

    void* GetTransform(void* obj, Il2CppClass* toyClass)
    {
        void* t = API::ReadInstanceField<void*>(toyClass, obj, "_transform", nullptr);
        if (t) return t;
        return InvokeMethod(Component_Class, obj, "get_transform", 0);
    }

    void* GetComponent(void* obj, Il2CppClass* targetClass)
    {
        if (!obj || !targetClass || !API::il2cpp_class_get_type || !API::il2cpp_type_get_object) return nullptr;
        void* typeObj = API::il2cpp_type_get_object(API::il2cpp_class_get_type(targetClass));
        if (!typeObj) return nullptr;
        void* params[1] = { typeObj };
        return InvokeMethod(Component_Class, obj, "GetComponent", 1, params);
    }

    Color ReadPrimitiveColor(void* obj)
    {
        // 1) direct _material field
        void* mat = API::ReadInstanceField<void*>(PrimitiveObjectToy_Class, obj, "_material", nullptr);

        // 2) Renderer().material
        if (!mat) {
            void* r = InvokeMethod(PrimitiveObjectToy_Class, obj, "GetRenderer", 0);
            if (r) mat = InvokeMethod(Renderer_Class, r, "get_material", 0);
        }
        if (mat) {
            Color col;
            if (InvokeValue(Material_Class, mat, "get_color", col))
                return col;
        }

        // 3) cached-material dictionary (RoleColor lookup)
        RoleColor rc = ::GetColorFromPrimitive((PrimitiveObjectToy*)obj);
        if (rc.r >= 0.f && rc.g >= 0.f && rc.b >= 0.f && rc.a >= 0.f)
            return Color{ rc.r, rc.g, rc.b, rc.a };

        return Color{ -1, -1, -1, -1 };
    }

    std::string Utf16ToUtf8(const wchar_t* w, int len)
    {
        if (!w || len <= 0) return {};
        int size = WideCharToMultiByte(CP_UTF8, 0, w, len, nullptr, 0, nullptr, nullptr);
        if (size <= 0) return {};
        std::string out((size_t)size, '\0');
        WideCharToMultiByte(CP_UTF8, 0, w, len, &out[0], size, nullptr, nullptr);
        return out;
    }

    // Unique per-object id (used as ObjectId in the schematic export).
    // Unity Object.GetInstanceID() is guaranteed unique; falls back to
    // Mirror netId if the method cannot be resolved.
    int ReadObjectId(void* obj)
    {
        if (!obj) return 0;

        // Unity instance id: unique per live object.
        if (Object_Class) {
            int v = 0;
            if (InvokeValue(Object_Class, obj, "GetInstanceID", v))
                return v;
        }

        // Mirror netId.
        if (const MethodInfo* m = API::FindMethod(AdminToyBase_Class, "get_netId", 0, true)) {
            void* exc = nullptr;
            void* r = API::il2cpp_runtime_invoke(m, obj, nullptr, &exc);
            if (r) return *(int*)r;
        }
        int v = API::ReadInstanceField<int>(AdminToyBase_Class, obj, "netId", 0);
        if (v) return v;
        v = API::ReadInstanceField<int>(AdminToyBase_Class, obj, "_netId", 0);
        return v;
    }

    // Name of the underlying GameObject (e.g. "Cube (07)", "FenceHcz").
    std::string ReadObjectName(void* obj)
    {
        if (!obj || !Component_Class || !Object_Class) return {};
        void* go = InvokeMethod(Component_Class, obj, "get_gameObject", 0);
        if (!go) return {};
        void* nm = InvokeMethod(Object_Class, go, "get_name", 0);
        if (!nm) return {};
        auto s = (Il2CppString*)nm;
        return Utf16ToUtf8(s->chars, s->length);
    }

    std::string ReadGameObjectName(void* obj)
    {
        std::string n = ReadObjectName(obj);
        return n;
    }

    // ---------------------------------------------------------------------------
    // PickupSyncInfo.ItemId layout resolution.
    //
    // ItemPickupBase stores its item type in a PickupSyncInfo.ItemId field.
    // Two shapes exist:
    //  - older builds: ItemId is an ItemIdentifier { Serial; ItemType }, a
    //    class (reference) whose pointer must be dereferenced before reading;
    //  - current builds: ItemId is the ItemType enum itself, stored inline at
    //    the START of the struct: ItemType(int)@0, Serial(ushort)@4,
    //    WeightKg(float)@8, _flags(int)@12 (verified by raw byte dumps).
    //    Note: il2cpp metadata in this build reports ItemId at +16, which does
    //    NOT match memory; both candidate offsets are validated below.
    // Naive field scanning reads raw bytes that land in the valid ItemType
    // range (0..60) by chance — that is exactly the "weapon became SCP-268 /
    // janitor card" symptom (44 / 0 are perfectly ordinary heap-address bytes).
    // ---------------------------------------------------------------------------
    struct ItemIdLayout {
        Il2CppClass* cls = nullptr;
        bool isClass = false;
        int typeOff   = -1; // offset of ItemType inside ItemIdentifier
        int serialOff = -1; // offset of Serial  inside ItemIdentifier
    };
    static ItemIdLayout g_itemIdLayout;

    void ResolveItemIdLayout()
    {
        if (g_itemIdLayout.cls) return;

        // Prefer the class reported by the ItemId field itself (always correct
        // for the current build).
        Il2CppClass* idCls = nullptr;
        if (PickupSyncInfo_Class && API::il2cpp_class_get_fields &&
            API::il2cpp_field_get_name && API::il2cpp_field_get_type && API::il2cpp_class_from_type) {
            void* iter = nullptr;
            while (Il2CppField* f = API::il2cpp_class_get_fields(PickupSyncInfo_Class, &iter)) {
                const char* fn = API::il2cpp_field_get_name(f);
                if (fn && strcmp(fn, "ItemId") == 0) {
                    Il2CppClass* fc = API::il2cpp_class_from_type(API::il2cpp_field_get_type(f));
                    if (fc) { idCls = fc; break; }
                }
            }
        }
        if (!idCls)
            idCls = API::FindClass("Assembly-CSharp", "InventorySystem.Items.Pickups", "ItemIdentifier");
        if (!idCls) return;

        g_itemIdLayout.cls = idCls;
        if (API::il2cpp_class_is_valuetype)
            g_itemIdLayout.isClass = !API::il2cpp_class_is_valuetype(idCls);
        g_itemIdLayout.typeOff = API::FindFieldOffset(idCls, "ItemType");
        if (g_itemIdLayout.typeOff < 0)
            g_itemIdLayout.typeOff = API::FindFieldOffset(idCls, "Type");
        g_itemIdLayout.serialOff = API::FindFieldOffset(idCls, "Serial");
    }

    // `p` points at an ItemId field: for a class ItemIdentifier this is the
    // pointer itself, for a struct the inline value. Returns ItemType (0..60)
    // or -1; optionally fills the serial.
    int ReadItemIdentifierType(void* p, uint32_t* serialOut = nullptr)
    {
        if (serialOut) *serialOut = 0;
        if (!p) return -1;
        if (g_itemIdLayout.cls && g_itemIdLayout.isClass) {
            p = *(void**)p; // dereference the reference field
            if (!p) return -1;
        }
        int type = -1;
        if (g_itemIdLayout.typeOff >= 0) {
            uint8_t v = *(uint8_t*)((uint8_t*)p + g_itemIdLayout.typeOff);
            if (v <= 60) type = (int)v;
        }
        if (serialOut && g_itemIdLayout.serialOff >= 0)
            *serialOut = *(uint32_t*)((uint8_t*)p + g_itemIdLayout.serialOff);
        return type;
    }
}

// ---------------------------------------------------------------------------
// Public SCPSL API
// ---------------------------------------------------------------------------
namespace SCPSL
{
    bool Init()
    {
        using API::FindClass;

        PrimitiveObjectToy_Class = FindClass("Assembly-CSharp", "AdminToys", "PrimitiveObjectToy");
        LightSourceToy_Class     = FindClass("Assembly-CSharp", "AdminToys", "LightSourceToy");
        TextToy_Class            = FindClass("Assembly-CSharp", "AdminToys", "TextToy");
        AdminToyBase_Class       = FindClass("Assembly-CSharp", "AdminToys", "AdminToyBase");
        MapEditor_Class          = FindClass("Assembly-CSharp", "", "MapEditor");
        if (!MapEditor_Class)    MapEditor_Class = FindClass("Assembly-CSharp", "MapEditor", "MapEditor");

        Object_Class      = FindClass("UnityEngine.CoreModule", "UnityEngine", "Object");
        Renderer_Class    = FindClass("UnityEngine.CoreModule", "UnityEngine", "Renderer");
        Material_Class    = FindClass("UnityEngine.CoreModule", "UnityEngine", "Material");
        Transform_Class   = FindClass("UnityEngine.CoreModule", "UnityEngine", "Transform");
        Component_Class   = FindClass("UnityEngine.CoreModule", "UnityEngine", "Component");
        Light_Class       = FindClass("UnityEngine.CoreModule", "UnityEngine", "Light");
        TextMesh_Class    = FindClass("UnityEngine.TextRenderingModule", "UnityEngine", "TextMesh");
        Application_Class = FindClass("UnityEngine.CoreModule", "UnityEngine", "Application");
        Cursor_Class      = FindClass("UnityEngine.CoreModule", "UnityEngine", "Cursor");

        ItemPickupBase_Class  = FindClass("Assembly-CSharp", "InventorySystem.Items.Pickups", "ItemPickupBase");
        PickupSyncInfo_Class  = FindClass("Assembly-CSharp", "InventorySystem.Items.Pickups", "PickupSyncInfo");
        FirearmPickup_Class   = FindClass("Assembly-CSharp", "InventorySystem.Items.Firearms", "FirearmPickup");
        if (!FirearmPickup_Class)
            FirearmPickup_Class = FindClass("Assembly-CSharp", "InventorySystem.Items.Firearms", "FirearmPickupBase");

        return PrimitiveObjectToy_Class != nullptr;
    }

    std::vector<void*> FindAllPrimitives()
    {
        return FindAllOfClass(PrimitiveObjectToy_Class);
    }

    std::vector<void*> FindAllLights()
    {
        return FindAllOfClass(LightSourceToy_Class);
    }

    std::vector<void*> FindAllTexts()
    {
        return FindAllOfClass(TextToy_Class);
    }

    std::vector<void*> FindAllPickups()
    {
        if (!ItemPickupBase_Class) return {};
        return FindAllOfClass(ItemPickupBase_Class);
    }

    PrimitiveData ReadPrimitive(void* obj)
    {
        PrimitiveData d;
        if (!obj) return d;

        Il2CppClass* k = API::il2cpp_object_get_class((Il2CppObject*)obj);
        const char* n = k ? API::il2cpp_class_get_name(k) : nullptr;
        d.name = n ? n : "Primitive";

        // Current version fields (found via class-field dump): no leading underscores.
        d.type  = API::ReadInstanceField<int>(PrimitiveObjectToy_Class, obj, "PrimitiveType", -1);
        d.flags = API::ReadInstanceField<int>(PrimitiveObjectToy_Class, obj, "PrimitiveFlags", -1);

        d.isStatic = API::ReadInstanceField<bool>(AdminToyBase_Class, obj, "IsStatic", false);
        d.parentId = API::ReadInstanceField<int>(AdminToyBase_Class, obj, "_clientParentId", 0);

        // World-space transform coordinates are what the export format needs.
        // il2cpp returns boxed values for struct getters; InvokeValue unboxes.
        bool okPos   = false;
        bool okRot   = false;
        bool okScale = false;
        void* tr = GetTransform(obj, PrimitiveObjectToy_Class);
        if (tr) {
            okPos   = ReadTransformVec(tr, "get_position",    d.pos);
            okRot   = ReadTransformVec(tr, "get_eulerAngles", d.rot);
            okScale = ReadTransformVec(tr, "get_lossyScale",  d.scale);
        }
        if (!okPos)   okPos   = ReadFieldVec(AdminToyBase_Class, obj, "Position", d.pos);
        if (!okRot)   okRot   = ReadFieldVec(AdminToyBase_Class, obj, "Rotation", d.rot);
        if (!okScale) okScale = ReadFieldVec(AdminToyBase_Class, obj, "Scale", d.scale);

        d.color     = API::ReadInstanceField<Color>(PrimitiveObjectToy_Class, obj, "MaterialColor", Color{ -1, -1, -1, -1 });
        d.baseColor = API::ReadInstanceField<Color>(PrimitiveObjectToy_Class, obj, "BaseColor", Color{ -1, -1, -1, -1 });

        if (d.color.r < 0.f) {
            d.color = ReadPrimitiveColor(obj);
        }

        std::string tn = ::GetName((PrimitiveType)d.type);
        d.typeName = tn.empty() ? "Unknown" : tn;

        d.objectId = ReadObjectId(obj);
        d.name = ReadGameObjectName(obj);
        if (d.name.empty()) d.name = n ? n : "Primitive";

        return d;
    }

    LightData ReadLight(void* obj)
    {
        LightData d;
        if (!obj) return d;

        Il2CppClass* k = API::il2cpp_object_get_class((Il2CppObject*)obj);
        const char* n = k ? API::il2cpp_class_get_name(k) : nullptr;
        d.name = n ? n : "Light";

        bool okPos   = false;
        bool okRot   = false;
        bool okScale = false;
        void* tr = GetTransform(obj, LightSourceToy_Class);
        if (tr) {
            okPos   = ReadTransformVec(tr, "get_position",    d.pos);
            okRot   = ReadTransformVec(tr, "get_eulerAngles", d.rot);
            okScale = ReadTransformVec(tr, "get_lossyScale",  d.scale);
        }
        if (!okPos)   okPos   = ReadFieldVec(AdminToyBase_Class, obj, "Position", d.pos);
        if (!okRot)   okRot   = ReadFieldVec(AdminToyBase_Class, obj, "Rotation", d.rot);
        if (!okScale) okScale = ReadFieldVec(AdminToyBase_Class, obj, "Scale", d.scale);

        d.parentId = API::ReadInstanceField<int>(AdminToyBase_Class, obj, "_clientParentId", 0);
        d.isStatic = API::ReadInstanceField<bool>(AdminToyBase_Class, obj, "IsStatic", false);

        d.color     = API::ReadInstanceField<Color>(LightSourceToy_Class, obj, "LightColor", Color{ -1, -1, -1, -1 });
        d.range     = API::ReadInstanceField<float>(LightSourceToy_Class, obj, "LightRange", 0.f);
        d.intensity = API::ReadInstanceField<float>(LightSourceToy_Class, obj, "LightIntensity", 0.f);

        // Some builds rename/move the LightSourceToy fields; the Light
        // component then carries the real values. Fall back whenever any of
        // the fields came back missing/zero — a real light always has a
        // nonzero range, so range<=0 is not the only signal.
        if (d.range <= 0.f || d.intensity <= 0.f) {
            void* lightComp = GetComponent(obj, Light_Class);
            if (lightComp) {
                float r = 0.f, i = 0.f;
                if (InvokeValue(Light_Class, lightComp, "get_range", r))
                    d.range = r;
                if (InvokeValue(Light_Class, lightComp, "get_intensity", i))
                    d.intensity = i;
            }
        }
        if (d.color.r < 0.f) {
            void* lightComp = GetComponent(obj, Light_Class);
            if (lightComp) {
                Color col;
                if (InvokeValue(Light_Class, lightComp, "get_color", col))
                    d.color = col;
            }
        }

        d.lightType      = API::ReadInstanceField<int>(LightSourceToy_Class, obj, "LightType", -1);
        d.shadowType     = API::ReadInstanceField<int>(LightSourceToy_Class, obj, "ShadowType", -1);
        d.shadowStrength = API::ReadInstanceField<float>(LightSourceToy_Class, obj, "ShadowStrength", 0.f);
        d.spotAngle      = API::ReadInstanceField<float>(LightSourceToy_Class, obj, "SpotAngle", 0.f);
        d.innerSpotAngle = API::ReadInstanceField<float>(LightSourceToy_Class, obj, "InnerSpotAngle", 0.f);

        d.objectId = ReadObjectId(obj);
        d.name = ReadGameObjectName(obj);
        if (d.name.empty()) d.name = n ? n : "Light";

        return d;
    }

    TextData ReadText(void* obj)
    {
        TextData d;
        if (!obj) return d;

        Il2CppClass* k = API::il2cpp_object_get_class((Il2CppObject*)obj);
        const char* n = k ? API::il2cpp_class_get_name(k) : nullptr;
        d.name = n ? n : "Text";

        // World-space transform coordinates.
        bool okPos   = false;
        bool okRot   = false;
        bool okScale = false;
        void* tr = GetTransform(obj, TextToy_Class);
        if (tr) {
            okPos   = ReadTransformVec(tr, "get_position",    d.pos);
            okRot   = ReadTransformVec(tr, "get_eulerAngles", d.rot);
            okScale = ReadTransformVec(tr, "get_lossyScale",  d.scale);
        }
        if (!okPos)   okPos   = ReadFieldVec(AdminToyBase_Class, obj, "Position", d.pos);
        if (!okRot)   okRot   = ReadFieldVec(AdminToyBase_Class, obj, "Rotation", d.rot);

        // For text the configured Scale field is authoritative: the live
        // transform's lossyScale is 1/20 of it (mesh normalization), so
        // reading the transform would make the text 20x too small.
        okScale = ReadFieldVec(AdminToyBase_Class, obj, "Scale", d.scale);
        if (!okScale && tr)
            okScale = ReadTransformVec(tr, "get_lossyScale", d.scale);

        d.parentId = API::ReadInstanceField<int>(AdminToyBase_Class, obj, "_clientParentId", 0);
        d.isStatic = API::ReadInstanceField<bool>(AdminToyBase_Class, obj, "IsStatic", false);

        // Text content: _textFormat is the configured format string and carries
        // the full rich-text markup (<size>, <color>, <b>, <smallcaps>, ...) the
        // schematic was built with. It is the authoritative source for the copy.
        d.text = ReadStringField(TextToy_Class, obj, "_textFormat");
        // Only if the format string is missing, read the live TextMesh text.
        if (d.text.empty()) {
            void* mesh = API::ReadInstanceField<void*>(TextToy_Class, obj, "_textMesh", nullptr);
            if (mesh) {
                void* t = InvokeMethod(TextMesh_Class ? TextMesh_Class : TextToy_Class, mesh, "get_text", 0);
                if (t) {
                    auto str = (Il2CppString*)t;
                    if (str && str->chars && str->length > 0)
                        d.text = Utf16ToUtf8(str->chars, str->length);
                }
            }
        }

        // DisplaySize: Vector2 field _displaySize.
        float w = 0.f, h = 0.f;
        if (ReadFieldValue<float>(TextToy_Class, obj, "_displaySize", w) &&
            ReadFieldValue<float>(TextToy_Class, obj, "_displaySize", h)) {
            // Vector2 is two adjacent floats; read both from the same offset.
            int32_t off = API::FindFieldOffset(TextToy_Class, "_displaySize");
            if (off >= 0) {
                w = *(float*)((uint8_t*)obj + off);
                h = *(float*)((uint8_t*)obj + off + sizeof(float));
            }
        }
        d.displayWidth  = w;
        d.displayHeight = h;

        d.objectId = ReadObjectId(obj);
        d.name = ReadGameObjectName(obj);
        if (d.name.empty()) d.name = n ? n : "Text";

        return d;
    }

    PickupData ReadPickup(void* obj)
    {
        PickupData d;
        if (!obj) return d;

        Il2CppClass* k = API::il2cpp_object_get_class((Il2CppObject*)obj);
        const char* n = k ? API::il2cpp_class_get_name(k) : nullptr;
        d.name = n ? n : "Pickup";

        // The item type lives in the ItemPickupBase Info/NetworkInfo field, a
        // PickupSyncInfo struct. The reliable path is PickupSyncInfo.ItemId
        // (ItemIdentifier) with the reference/pointer properly dereferenced;
        // only if that fails we scan every field and accept the first
        // plausible value.
        auto readItemTypeAt = [&](uint8_t* base, uint32_t* serialOut = nullptr) {
            if (serialOut) *serialOut = 0;
            if (!base || !PickupSyncInfo_Class || !API::il2cpp_class_get_fields ||
                !API::il2cpp_field_get_name || !API::il2cpp_field_get_offset)
                return -1;
            ResolveItemIdLayout();
            int idOff = API::FindFieldOffset(PickupSyncInfo_Class, "ItemId");
            // 1) Current builds: the ItemId field IS the ItemType enum, inline
            //    at the start of the struct. Metadata may report a shifted
            //    offset (+16), so try both candidates and keep the plausible one.
            bool directEnum = g_itemIdLayout.cls &&
                API::il2cpp_class_get_name && API::il2cpp_class_is_valuetype &&
                strcmp(API::il2cpp_class_get_name(g_itemIdLayout.cls), "ItemType") == 0 &&
                API::il2cpp_class_is_valuetype(g_itemIdLayout.cls) != 0;
            if (directEnum) {
                int bestCand = -1, bestType = -1, bestScore = -1;
                uint32_t bestSerial = 0;
                for (int c : { 0, idOff }) {
                    if (c < 0) continue;
                    int t = *(int*)(base + c);
                    if (t < 0 || t > 60) continue;
                    uint32_t s = *(uint16_t*)(base + c + 4);
                    float w = *(float*)(base + c + 8);
                    int score = 100 + (s != 0 ? 10 : 0) +
                                (std::isfinite(w) && w >= 0.f && w <= 500.f ? 5 : 0);
                    if (score > bestScore) {
                        bestScore = score;
                        bestCand = c;
                        bestType = t;
                        bestSerial = s;
                    }
                }
                if (bestCand >= 0) {
                    if (serialOut) *serialOut = bestSerial;
                    return bestType;
                }
            }
            // 2) Older builds: ItemId is an ItemIdentifier reference/struct.
            if (idOff >= 0) {
                int v = ReadItemIdentifierType(base + idOff, serialOut);
                if (v >= 0 && v <= 60) return v;
            }
            // 3) Legacy fallback: scan every field, accept the first byte in
            // the plausible enum range.
            void* iter = nullptr;
            while (Il2CppField* f = API::il2cpp_class_get_fields(PickupSyncInfo_Class, &iter)) {
                int off = (int)API::il2cpp_field_get_offset(f);
                if (off < 0) continue;
                const char* fn = API::il2cpp_field_get_name(f);
                if (fn && off == idOff) continue; // already handled above
                Il2CppClass* fc = nullptr;
                if (API::il2cpp_field_get_type && API::il2cpp_class_from_type)
                    fc = API::il2cpp_class_from_type(API::il2cpp_field_get_type(f));
                if (fc) {
                    // Nested struct with a Type/ItemType field.
                    int nested = API::FindFieldOffset(fc, "Type");
                    if (nested < 0) nested = API::FindFieldOffset(fc, "ItemType");
                    if (nested >= 0) {
                        int v = *(uint8_t*)(base + off + nested);
                        if (v >= 0 && v <= 60) return v;
                    }
                    // Field is itself an ItemType enum.
                    const char* cn = API::il2cpp_class_get_name ? API::il2cpp_class_get_name(fc) : nullptr;
                    if (cn && strcmp(cn, "ItemType") == 0) {
                        int v = *(uint8_t*)(base + off);
                        if (v >= 0 && v <= 60) return v;
                    }
                }
            }
            return -1;
        };

        uint8_t* info = nullptr;
        int itemType = -1;
        uint32_t serial = 0;

        // 1) Inline backing fields (no boxing, deterministic layout).
        for (const char* field : { "_info", "Info", "_networkInfo", "NetworkInfo" }) {
            int off = API::FindFieldOffset(ItemPickupBase_Class, field);
            if (off < 0) continue;
            uint32_t s = 0;
            int v = readItemTypeAt((uint8_t*)obj + off, &s);
            if (v >= 0 && v <= 60) {
                info = (uint8_t*)obj + off;
                itemType = v;
                serial = s;
                break;
            }
        }

        // 2) Property getters — try direct pointer, then boxed+unboxed.
        if (!info) {
            for (const char* getter : { "get_Info", "get_NetworkInfo" }) {
                const MethodInfo* m = API::FindMethod(ItemPickupBase_Class, getter, 0, true);
                if (!m || !API::il2cpp_runtime_invoke) continue;
                void* exc = nullptr;
                void* r = API::il2cpp_runtime_invoke(m, obj, nullptr, &exc);
                if (!r) continue;
                uint32_t s = 0;
                int v = readItemTypeAt((uint8_t*)r, &s);
                if (v >= 0 && v <= 60) {
                    info = (uint8_t*)r;
                    itemType = v;
                    serial = s;
                    break;
                }
                if (API::il2cpp_object_unbox) {
                    uint8_t* unboxed = (uint8_t*)API::il2cpp_object_unbox((Il2CppObject*)r);
                    v = readItemTypeAt(unboxed, &s);
                    if (v >= 0 && v <= 60) {
                        info = unboxed;
                        itemType = v;
                        serial = s;
                        break;
                    }
                }
            }
        }

        if (info) {
            d.itemType = itemType >= 0 && itemType <= 60 ? itemType : 0;
            d.serial = serial;
            int lockOff  = API::FindFieldOffset(PickupSyncInfo_Class, "Locked");
            int inUseOff = API::FindFieldOffset(PickupSyncInfo_Class, "InUse");
            if (lockOff >= 0)
                d.isLocked = *(bool*)(info + lockOff);
            if (inUseOff >= 0)
                d.inUse = *(bool*)(info + inUseOff);
        }

        d.attachmentsCode = ReadStringField(ItemPickupBase_Class, obj, "_attachmentsCode");
        if (d.attachmentsCode.empty())
            d.attachmentsCode = ReadStringField(ItemPickupBase_Class, obj, "AttachmentsCode");
        d.uses = API::ReadInstanceField<int>(ItemPickupBase_Class, obj, "Uses", 1);
        if (d.uses <= 0)
            d.uses = API::ReadInstanceField<int>(ItemPickupBase_Class, obj, "NumberOfUses", 1);

        void* tr = GetTransform(obj, ItemPickupBase_Class);
        if (tr) {
            ReadTransformVec(tr, "get_position",    d.pos);
            ReadTransformVec(tr, "get_eulerAngles", d.rot);
            ReadTransformVec(tr, "get_lossyScale",  d.scale);
        }

        d.objectId = ReadObjectId(obj);
        d.name = ReadGameObjectName(obj);
        if (d.name.empty()) d.name = n ? n : "Pickup";

        return d;
    }

    // Returns the Transform of a component object, or null.
    void* GetComponentTransform(void* obj, Il2CppClass* cls)
    {
        if (!obj) return nullptr;
        return GetTransform(obj, cls);
    }

    // Returns the parent Transform of a Transform, or null.
    void* TransformGetParent(void* tr)
    {
        if (!tr || !Transform_Class) return nullptr;
        return InvokeMethod(Transform_Class, tr, "get_parent", 0);
    }

    std::string GameVersion()
    {
        if (!Application_Class) return "unknown";
        void* exc = nullptr;
        void* r = InvokeMethod(Application_Class, nullptr, "get_version", 0, nullptr, &exc);
        if (!r) return "unknown";
        auto s = (Il2CppString*)r;
        return Utf16ToUtf8(s->chars, s->length);
    }

    std::string DebugDump()
    {
        std::string out;
        auto add = [&](const std::string& s) { out += s; out += "\n"; };
        auto st  = [](Il2CppClass* c) { return c ? "OK" : "NOT FOUND"; };

        add("=== SCP:SL Mod Debug Dump ===");
        add(std::string("GameAssembly.dll: ") + (API::gameAssembly ? "loaded" : "MISSING"));
        add(std::string("domain: ") + (domain ? std::to_string((uintptr_t)domain) : "null"));
        add(std::string("api exports: ") + (API::il2cpp_domain_get ? "ok" : "MISSING"));

        if (domain && API::il2cpp_domain_get_assemblies && API::il2cpp_assembly_get_image && API::il2cpp_image_get_name) {
            size_t n = 0;
            const Il2CppAssembly** asmbl = API::il2cpp_domain_get_assemblies(domain, &n);
            add(std::string("assemblies: ") + std::to_string(n));
            for (size_t i = 0; i < n; i++) {
                if (!asmbl[i]) continue;
                Il2CppImage* img = API::il2cpp_assembly_get_image(asmbl[i]);
                if (img) add("  [" + std::to_string(i) + "] " + API::il2cpp_image_get_name(img));
            }
        }

        add(std::string("PrimitiveObjectToy: ") + st(PrimitiveObjectToy_Class));
        add(std::string("LightSourceToy:     ") + st(LightSourceToy_Class));
        add(std::string("AdminToyBase:       ") + st(AdminToyBase_Class));
        add(std::string("MapEditor:          ") + st(MapEditor_Class));
        add(std::string("Object:             ") + st(Object_Class));
        add(std::string("Renderer:           ") + st(Renderer_Class));
        add(std::string("Material:           ") + st(Material_Class));
        add(std::string("Transform:          ") + st(Transform_Class));
        add(std::string("Component:          ") + st(Component_Class));
        add(std::string("Light:              ") + st(Light_Class));

        if (MapEditor_Class) {
            Il2CppField* f = API::FindField(MapEditor_Class, "Objects");
            if (f) {
                void* list = nullptr;
                API::il2cpp_field_static_get_value(f, &list);
                if (list) {
                    Il2CppClass* lc = API::il2cpp_object_get_class((Il2CppObject*)list);
                    add(std::string("MapEditor.Objects: present (") +
                        (lc && API::il2cpp_class_get_name ? API::il2cpp_class_get_name(lc) : "?") + ")");
                    if (lc) {
                        Il2CppField* sz = API::FindField(lc, "_size");
                        if (sz) {
                            int v = 0;
                            API::il2cpp_field_get_value((Il2CppObject*)list, sz, &v);
                            add(std::string("  list _size = ") + std::to_string(v));
                        }
                    }
                } else {
                    add("MapEditor.Objects: field exists, value null");
                }
            } else {
                add("MapEditor.Objects: FIELD NOT FOUND");
            }
        }

        if (API::il2cpp_image_get_class_count && API::il2cpp_image_get_class && API::il2cpp_class_get_namespace) {
            Il2CppImage* img = API::FindImage("Assembly-CSharp");
            if (img) {
                size_t cnt = API::il2cpp_image_get_class_count(img);
                add(std::string("Assembly-CSharp classes: ") + std::to_string(cnt));
                static const char* kw[] = { "Map", "Schematic", "Editor", "Toy", "Block", "Admin", "Light", "Object", "Pickup", "Item" };
                for (size_t i = 0; i < cnt; i++) {
                    Il2CppClass* c = API::il2cpp_image_get_class(img, i);
                    if (!c || !API::il2cpp_class_get_name) continue;
                    const char* nm = API::il2cpp_class_get_name(c);
                    const char* ns = API::il2cpp_class_get_namespace(c);
                    bool hit = false;
                    for (const char* k : kw)
                        if (strstr(nm, k) || strstr(ns, k)) { hit = true; break; }
                    if (hit) add("  " + std::string(ns) + "." + nm);
                }
            } else {
                add("Assembly-CSharp image NOT FOUND");
            }
        }

        add("=== Sample primitives (new fields) ===");
        {
            auto prims = FindAllPrimitives();
            int shown = 0;
            for (size_t i = 0; i < prims.size() && shown < 5; i++) {
                void* obj = prims[i];
                PrimitiveData d = ReadPrimitive(obj);
                add("  #" + std::to_string(shown) + " class=" + d.name +
                    " type=" + std::to_string(d.type) +
                    " flags=" + std::to_string(d.flags) +
                    " static=" + std::to_string(d.isStatic ? 1 : 0) +
                    " objectId=" + std::to_string(d.objectId) +
                    " parentId=" + std::to_string(d.parentId));
                add("    pos=" + std::to_string(d.pos.x) + "," + std::to_string(d.pos.y) + "," + std::to_string(d.pos.z) +
                    " rot=" + std::to_string(d.rot.x) + "," + std::to_string(d.rot.y) + "," + std::to_string(d.rot.z) +
                    " scale=" + std::to_string(d.scale.x) + "," + std::to_string(d.scale.y) + "," + std::to_string(d.scale.z));
                add("    color=" + std::to_string(d.color.r) + "," + std::to_string(d.color.g) + "," + std::to_string(d.color.b) + "," + std::to_string(d.color.a) +
                    " baseColor=" + std::to_string(d.baseColor.r) + "," + std::to_string(d.baseColor.g) + "," + std::to_string(d.baseColor.b) + "," + std::to_string(d.baseColor.a));
                shown++;
            }
            add("  (primitives found: " + std::to_string(prims.size()) + ")");
        }

        add("=== Sample lights ===");
        {
            auto ls = FindAllLights();
            int shown = 0;
            for (size_t i = 0; i < ls.size() && shown < 8; i++) {
                void* obj = ls[i];
                LightData d = ReadLight(obj);
                add("  #" + std::to_string(shown) + " class=" + d.name +
                    " parentId=" + std::to_string(d.parentId) +
                    " objectId=" + std::to_string(d.objectId));
                add("    pos=" + std::to_string(d.pos.x) + "," + std::to_string(d.pos.y) + "," + std::to_string(d.pos.z) +
                    " type=" + std::to_string(d.lightType) +
                    " range=" + std::to_string(d.range) +
                    " intensity=" + std::to_string(d.intensity) +
                    " color=" + std::to_string(d.color.r) + "," + std::to_string(d.color.g) + "," + std::to_string(d.color.b) + "," + std::to_string(d.color.a));
                shown++;
            }
            add("  (lights found: " + std::to_string(ls.size()) + ")");
        }

        add("=== Sample texts ===");
        {
            auto ts = FindAllTexts();
            int shown = 0;
            for (size_t i = 0; i < ts.size() && shown < 5; i++) {
                void* obj = ts[i];
                TextData d = ReadText(obj);
                add("  #" + std::to_string(shown) + " class=" + d.name +
                    " parentId=" + std::to_string(d.parentId) +
                    " objectId=" + std::to_string(d.objectId));
                add("    pos=" + std::to_string(d.pos.x) + "," + std::to_string(d.pos.y) + "," + std::to_string(d.pos.z) +
                    " text=" + d.text +
                    " disp=" + std::to_string(d.displayWidth) + "x" + std::to_string(d.displayHeight));
                shown++;
            }
            add("  (texts found: " + std::to_string(ts.size()) + ")");
        }

        add("=== Sample pickups ===");
        {
            add(std::string("  ItemPickupBase class: ") + st(ItemPickupBase_Class));
            add(std::string("  PickupSyncInfo class: ") + st(PickupSyncInfo_Class));
            ResolveItemIdLayout();
            add(std::string("  ItemId field class: ") +
                (g_itemIdLayout.cls ? (API::il2cpp_class_get_name ? API::il2cpp_class_get_name(g_itemIdLayout.cls) : "?") : "NOT FOUND") +
                " isClass=" + std::to_string(g_itemIdLayout.isClass ? 1 : 0) +
                " typeOff=" + std::to_string(g_itemIdLayout.typeOff) +
                " serialOff=" + std::to_string(g_itemIdLayout.serialOff));
            if (PickupSyncInfo_Class && API::il2cpp_class_get_fields && API::il2cpp_field_get_name && API::il2cpp_field_get_offset) {
                void* iter = nullptr;
                while (Il2CppField* f = API::il2cpp_class_get_fields(PickupSyncInfo_Class, &iter)) {
                    int off = (int)API::il2cpp_field_get_offset(f);
                    const char* fn = API::il2cpp_field_get_name(f);
                    std::string tn = "?";
                    if (API::il2cpp_field_get_type && API::il2cpp_class_from_type) {
                        Il2CppClass* fc = API::il2cpp_class_from_type(API::il2cpp_field_get_type(f));
                        tn = fc && API::il2cpp_class_get_name ? API::il2cpp_class_get_name(fc) : "?";
                    }
                    add(std::string("  PickupSyncInfo.") + fn + " @ " + std::to_string(off) + " (" + tn + ")");
                }
            }
            auto ps = FindAllPickups();
            int shown = 0;
            for (size_t i = 0; i < ps.size() && shown < 8; i++) {
                void* obj = ps[i];
                PickupData d = ReadPickup(obj);
                add("  #" + std::to_string(shown) + " class=" + d.name +
                    " itemType=" + std::to_string(d.itemType) +
                    " serial=" + std::to_string(d.serial) +
                    " uses=" + std::to_string(d.uses) +
                    " locked=" + std::to_string(d.isLocked) +
                    " attach=" + d.attachmentsCode);
                add("    pos=" + std::to_string(d.pos.x) + "," + std::to_string(d.pos.y) + "," + std::to_string(d.pos.z) +
                    " rot=" + std::to_string(d.rot.x) + "," + std::to_string(d.rot.y) + "," + std::to_string(d.rot.z) +
                    " scale=" + std::to_string(d.scale.x) + "," + std::to_string(d.scale.y) + "," + std::to_string(d.scale.z));
                // Raw bytes of the Info field (inline) to inspect the real layout.
                int off = API::FindFieldOffset(ItemPickupBase_Class, "_info");
                if (off < 0) off = API::FindFieldOffset(ItemPickupBase_Class, "Info");
                if (off >= 0) {
                    uint8_t* p = (uint8_t*)obj + off;
                    std::string hex;
                    for (int b = 0; b < 32; b++) {
                        char tmp[8];
                        snprintf(tmp, sizeof(tmp), "%02X ", p[b]);
                        hex += tmp;
                    }
                    add("    infoRaw: " + hex);
                } else {
                    add("    infoRaw: _info field NOT FOUND");
                }
                shown++;
            }
            add("  (pickups found: " + std::to_string(ps.size()) + ")");
        }

        add("=== Sample transform/room diagnostics ===");
        {
            auto prims = FindAllPrimitives();
            for (size_t i = 0; i < prims.size() && i < 3; i++) {
                void* obj = prims[i];
                Vector3 fpos{}, frot{}, fscale{};
                bool fp = ReadFieldVec(AdminToyBase_Class, obj, "Position", fpos);
                bool fr = ReadFieldVec(AdminToyBase_Class, obj, "Rotation", frot);
                bool fs = ReadFieldVec(AdminToyBase_Class, obj, "Scale", fscale);

                Vector3 tpos{}, trot{}, tscale{};
                void* tr = GetTransform(obj, PrimitiveObjectToy_Class);
                bool tp = tr && ReadTransformVec(tr, "get_position", tpos);
                bool trr = tr && ReadTransformVec(tr, "get_eulerAngles", trot);
                bool ts = tr && ReadTransformVec(tr, "get_lossyScale", tscale);

                void* room = API::ReadInstanceField<void*>(PrimitiveObjectToy_Class, obj, "<OriginalRoom>k__BackingField", nullptr);
                std::string roomName = "null";
                Vector3 rpos{};
                bool rp = false;
                if (room) {
                    roomName = ReadObjectName(room);
                    void* rtr = GetTransform(room, nullptr);
                    rp = rtr && ReadTransformVec(rtr, "get_position", rpos);
                }

                add(std::string("  #") + std::to_string(i) +
                    " fieldPos=" + (fp ? std::to_string(fpos.x) + "," + std::to_string(fpos.y) + "," + std::to_string(fpos.z) : "n/a") +
                    " fieldRot=" + (fr ? std::to_string(frot.x) + "," + std::to_string(frot.y) + "," + std::to_string(frot.z) : "n/a") +
                    " fieldScale=" + (fs ? std::to_string(fscale.x) + "," + std::to_string(fscale.y) + "," + std::to_string(fscale.z) : "n/a"));
                add(std::string("      trPos=" + (tp ? std::to_string(tpos.x) + "," + std::to_string(tpos.y) + "," + std::to_string(tpos.z) : "n/a") +
                    " trRot=" + (trr ? std::to_string(trot.x) + "," + std::to_string(trot.y) + "," + std::to_string(trot.z) : "n/a") +
                    " trScale=" + (ts ? std::to_string(tscale.x) + "," + std::to_string(tscale.y) + "," + std::to_string(tscale.z) : "n/a")));
                add(std::string("      room=" + roomName +
                    " roomPos=" + (rp ? std::to_string(rpos.x) + "," + std::to_string(rpos.y) + "," + std::to_string(rpos.z) : "n/a")));
            }
        }

        add("=== PrimitiveType enum values ===");
        {
            Il2CppClass* pt = API::FindClass("Assembly-CSharp", "AdminToys", "PrimitiveType");
            if (pt && API::il2cpp_class_get_fields && API::il2cpp_field_get_name && API::il2cpp_field_static_get_value) {
                void* iter = nullptr;
                while (Il2CppField* f = API::il2cpp_class_get_fields(pt, &iter)) {
                    const char* fn = API::il2cpp_field_get_name(f);
                    if (!fn || strcmp(fn, "value__") == 0) continue;
                    int val = 0;
                    API::il2cpp_field_static_get_value(f, &val);
                    add(std::string("  ") + fn + " = " + std::to_string(val));
                }
            } else {
                add("  (PrimitiveType enum not resolvable)");
            }
        }

        add("=== AdminToys fields ===");
        {
            static const char* kw[] = { "Admin", "Schematic", "Block" };
            Il2CppImage* img = API::FindImage("Assembly-CSharp");
            if (img && API::il2cpp_image_get_class_count && API::il2cpp_image_get_class) {
                size_t cnt = API::il2cpp_image_get_class_count(img);
                for (size_t i = 0; i < cnt; i++) {
                    Il2CppClass* c = API::il2cpp_image_get_class(img, i);
                    if (!c || !API::il2cpp_class_get_name || !API::il2cpp_class_get_namespace) continue;
                    const char* ns = API::il2cpp_class_get_namespace(c);
                    const char* nm = API::il2cpp_class_get_name(c);
                    if (!ns || !nm) continue;
                    bool hit = false;
                    for (const char* k : kw)
                        if (strstr(ns, k) || strstr(nm, k)) { hit = true; break; }
                    if (!hit) continue;
                    if (strstr(ns, "UnityEngine") || strstr(ns, "System")) continue;
                    add("-- " + std::string(ns) + "." + nm);
                    if (!API::il2cpp_class_get_fields || !API::il2cpp_field_get_name) continue;
                    void* iter = nullptr;
                    int fi = 0;
                    while (Il2CppField* f = API::il2cpp_class_get_fields(c, &iter)) {
                        const char* fn = API::il2cpp_field_get_name(f);
                        if (fn) add("    [" + std::to_string(fi) + "] " + fn);
                        fi++;
                    }
                }
            }
        }

        return out;
    }

    void ForceUnlockCursor()
    {
        if (!Cursor_Class) return;
        void* exc = nullptr;
        if (const MethodInfo* m = API::FindMethod(Cursor_Class, "set_lockState", 1, false)) {
            void* params[1] = { (void*)0 };  // CursorLockMode.None
            API::il2cpp_runtime_invoke(m, nullptr, params, &exc);
        }
        if (const MethodInfo* m = API::FindMethod(Cursor_Class, "set_visible", 1, false)) {
            void* params[1] = { (void*)1 };
            API::il2cpp_runtime_invoke(m, nullptr, params, &exc);
        }
    }
}

// ---------------------------------------------------------------------------
// Game type wrappers
// ---------------------------------------------------------------------------
int PrimitiveObjectToy::GetFlags() const
{
    return API::ReadInstanceField<int>(SCPSL::PrimitiveObjectToy_Class, (void*)this, "_flags", -1);
}

Renderer* PrimitiveObjectToy::GetRenderer() const
{
    return (Renderer*)InvokeMethod(SCPSL::PrimitiveObjectToy_Class, (void*)this, "GetRenderer", 0);
}

namespace
{
    void* GetCachedMaterialsDict()
    {
        if (!SCPSL::PrimitiveObjectToy_Class) return nullptr;
        if (const MethodInfo* m = API::FindMethod(SCPSL::PrimitiveObjectToy_Class, "GetCachedMaterials", 0, true)) {
            void* exc = nullptr;
            return API::il2cpp_runtime_invoke(m, nullptr, nullptr, &exc);
        }
        return API::ReadStaticField<void*>(SCPSL::PrimitiveObjectToy_Class, "CachedMaterials", nullptr);
    }
}

CachedMaterialsView* PrimitiveObjectToy::GetCachedMaterials()
{
    static CachedMaterialsView v;
    v = CachedMaterialsView::From(GetCachedMaterialsDict());
    return &v;
}

CachedMaterialsView CachedMaterialsView::From(void* dictObject)
{
    CachedMaterialsView v;
    v.dict = dictObject;
    if (!dictObject) return v;

    Il2CppClass* dc = API::il2cpp_object_get_class((Il2CppObject*)dictObject);
    if (!dc) return v;

    Il2CppField* fEntries = API::FindField(dc, "_entries");
    Il2CppField* fCount   = API::FindField(dc, "_count");
    if (!fEntries || !fCount) return v;

    API::il2cpp_field_get_value((Il2CppObject*)dictObject, fEntries, &v.entries);
    API::il2cpp_field_get_value((Il2CppObject*)dictObject, fCount, &v.count);

    if (API::il2cpp_field_get_type && API::il2cpp_class_from_type && API::il2cpp_array_class_get && API::il2cpp_class_get_size) {
        Il2CppClass* arrayClass = API::il2cpp_class_from_type(API::il2cpp_field_get_type(fEntries));
        Il2CppClass* entryClass = arrayClass ? API::il2cpp_array_class_get(arrayClass, 0) : nullptr;
        if (entryClass) {
            if (Il2CppField* f = API::il2cpp_class_get_field_from_name(entryClass, "key"))   v.keyOffset   = API::il2cpp_field_get_offset(f);
            if (Il2CppField* f = API::il2cpp_class_get_field_from_name(entryClass, "value")) v.valueOffset = API::il2cpp_field_get_offset(f);
            v.entrySize = API::il2cpp_class_get_size(entryClass);
        }
    }

    // Fallback layout for Dictionary<RoleColor, Material>:
    // entry = { int hashCode; int next; RoleColor key; Material value; }
    if (v.entrySize == 0 || v.entrySize > 64) {
        v.keyOffset   = 8;
        v.valueOffset = 24;
        v.entrySize   = 32;
    }
    return v;
}

RoleColor CachedMaterialsView::get_Key(size_t i) const
{
    if (!entries || i >= (size_t)count || entrySize == 0) return { -1, -1, -1, -1 };
    return *(RoleColor*)((uint8_t*)entries + sizeof(Il2CppArray) + i * entrySize + keyOffset);
}

void* CachedMaterialsView::get_Value(size_t i) const
{
    if (!entries || i >= (size_t)count || entrySize == 0) return nullptr;
    return *(void**)((uint8_t*)entries + sizeof(Il2CppArray) + i * entrySize + valueOffset);
}

RoleColorArray CachedMaterialsView::get_Keys() const
{
    return RoleColorArray{ this };
}

MaterialArray CachedMaterialsView::get_Values() const
{
    return MaterialArray{ this };
}

Material* Renderer::GetMaterial() const
{
    return (Material*)InvokeMethod(SCPSL::Renderer_Class, (void*)this, "get_material", 0);
}

void* Material::GetColorRaw() const
{
    return InvokeMethod(SCPSL::Material_Class, (void*)this, "get_color", 0);
}
