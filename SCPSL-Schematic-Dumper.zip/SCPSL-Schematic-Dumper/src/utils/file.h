#pragma once

#include <string>

namespace FileUtils
{
    // Full path of the user's Desktop folder.
    std::string GetDesktopPath();

    // Creates a directory (recursively). Returns the created path, or empty on failure.
    std::string CreateFolder(const std::string& path);

    // Removes characters that are invalid in Windows file names.
    std::string SanitizeFileName(const std::string& name);

    // Writes UTF-8 content to a file. Returns true on success.
    bool WriteTextFile(const std::string& path, const std::string& content);
}
