#include "dx11hook.h"
#include <d3d11.h>
#include <dxgi.h>
#include "../menu/menu.h"
#include "../sdk/scpsl.h"
#include "../features/schematic_dumper.h"
#include "../shutdown.h"
#include "imgui.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_win32.h"

// Forward-declared (the header intentionally keeps this in an #if 0 block to
// avoid dragging <windows.h> dependencies).
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace
{
    constexpr UINT VTABLE_PRESENT  = 8;
    constexpr UINT VTABLE_RESIZE   = 13;

    typedef HRESULT(__stdcall* fnPresent)(IDXGISwapChain*, UINT, UINT);
    typedef HRESULT(__stdcall* fnResizeBuffers)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);

    fnPresent       oPresent       = nullptr;
    fnResizeBuffers oResizeBuffers = nullptr;

    bool g_ready = false;
    ID3D11Device*        g_device  = nullptr;
    ID3D11DeviceContext* g_context = nullptr;
    HWND                 g_hwnd    = nullptr;
    WNDPROC              g_origWndProc = nullptr;
    IDXGISwapChain*      g_patchedChain = nullptr;
    bool                 g_unloadRequested = false;

    void UnhookVtable()
    {
        if (!g_patchedChain || !oPresent || !oResizeBuffers)
            return;
        uintptr_t* vtable = *(uintptr_t**)g_patchedChain;
        DWORD oldProtect = 0;
        if (VirtualProtect(&vtable[VTABLE_PRESENT], sizeof(void*), PAGE_EXECUTE_READWRITE, &oldProtect)) {
            vtable[VTABLE_PRESENT] = (uintptr_t)oPresent;
            VirtualProtect(&vtable[VTABLE_PRESENT], sizeof(void*), oldProtect, &oldProtect);
        }
        if (VirtualProtect(&vtable[VTABLE_RESIZE], sizeof(void*), PAGE_EXECUTE_READWRITE, &oldProtect)) {
            vtable[VTABLE_RESIZE] = (uintptr_t)oResizeBuffers;
            VirtualProtect(&vtable[VTABLE_RESIZE], sizeof(void*), oldProtect, &oldProtect);
        }
    }

    void UnhookWndProc()
    {
        if (g_origWndProc && g_hwnd) {
            SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)g_origWndProc);
            g_origWndProc = nullptr;
        }
    }

    void ShutdownImGui()
    {
        if (g_ready) {
            ImGui_ImplDX11_Shutdown();
            ImGui_ImplWin32_Shutdown();
            ImGui::DestroyContext();
            g_ready = false;
        }
        if (g_device) { g_device->Release(); g_device = nullptr; }
        if (g_context) { g_context->Release(); g_context = nullptr; }
    }

    LRESULT __stdcall WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
    {
        if (Menu::Opened && ImGui_ImplWin32_WndProcHandler(hwnd, msg, wParam, lParam))
            return 1L;
        return CallWindowProcW(g_origWndProc, hwnd, msg, wParam, lParam);
    }

    void InitImGui(IDXGISwapChain* realChain)
    {
        if (g_ready) return;
        if (!realChain) return;
        if (FAILED(realChain->GetDevice(__uuidof(ID3D11Device), (void**)&g_device))) return;
        g_device->GetImmediateContext(&g_context);

        g_hwnd = FindWindowW(nullptr, L"SCPSL");
        if (!g_hwnd) return;

        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.IniFilename = nullptr;
        io.LogFilename = nullptr;
        ImGui::StyleColorsDark();

        ImGui_ImplWin32_Init(g_hwnd);
        ImGui_ImplDX11_Init(g_device, g_context);

        g_origWndProc = (WNDPROC)SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)WndProc);
        g_ready = true;
    }

    HRESULT __stdcall hkPresent(IDXGISwapChain* sc, UINT syncInterval, UINT flags)
    {
        if (g_unloadRequested)
            return oPresent(sc, syncInterval, flags);

        if (!g_ready)
            InitImGui(sc);

        if (GetAsyncKeyState(VK_INSERT) & 1)
            Menu::Toggle();

        // Keep accumulating newly-spawned schematic blocks while progressive
        // capture is active (runs regardless of whether the menu is open).
        SchematicDumper::Tick();

        if (g_ready && Menu::Opened) {
            ImGui_ImplDX11_NewFrame();
            ImGui_ImplWin32_NewFrame();
            ImGui::NewFrame();
            Menu::Render();
            ImGui::Render();
            ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        }

        return oPresent(sc, syncInterval, flags);
    }

    HRESULT __stdcall hkResizeBuffers(IDXGISwapChain* sc, UINT count, UINT w, UINT h, DXGI_FORMAT f, UINT flags)
    {
        if (g_ready)
            ImGui_ImplDX11_InvalidateDeviceObjects();
        HRESULT hr = oResizeBuffers(sc, count, w, h, f, flags);
        if (g_ready)
            ImGui_ImplDX11_CreateDeviceObjects();
        return hr;
    }

    void HookVtable(void* obj, UINT index, void* hook, void** original)
    {
        uintptr_t* vtable = *(uintptr_t**)obj;
        DWORD oldProtect = 0;
        if (VirtualProtect(&vtable[index], sizeof(void*), PAGE_EXECUTE_READWRITE, &oldProtect)) {
            *original = (void*)vtable[index];
            vtable[index] = (uintptr_t)hook;
            VirtualProtect(&vtable[index], sizeof(void*), oldProtect, &oldProtect);
        }
    }
}

namespace DX11Hook
{
    bool Initialize()
    {
        // Create a dummy window + swapchain. All DXGI swapchains created by the
        // same runtime share the interface vtable, so patching this one also
        // patches the game's real swapchain.
        static HWND dummyWnd = nullptr;
        if (dummyWnd) return true;

        dummyWnd = CreateWindowExW(0, L"STATIC", L"", WS_POPUP, 0, 0, 1, 1,
                                   nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
        if (!dummyWnd) return false;

        DXGI_SWAP_CHAIN_DESC sd{};
        sd.BufferCount = 1;
        sd.BufferDesc.Width  = 1;
        sd.BufferDesc.Height = 1;
        sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        sd.OutputWindow = dummyWnd;
        sd.SampleDesc.Count = 1;
        sd.Windowed = TRUE;

        ID3D11Device* dev = nullptr;
        ID3D11DeviceContext* ctx = nullptr;
        IDXGISwapChain* chain = nullptr;
        HRESULT hr = D3D11CreateDeviceAndSwapChain(
            nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0,
            D3D11_SDK_VERSION, &sd, &chain, &dev, nullptr, &ctx);
        if (FAILED(hr) || !chain) {
            DestroyWindow(dummyWnd);
            dummyWnd = nullptr;
            return false;
        }

        HookVtable(chain, VTABLE_PRESENT, (void*)hkPresent, (void**)&oPresent);
        HookVtable(chain, VTABLE_RESIZE,  (void*)hkResizeBuffers, (void**)&oResizeBuffers);

        g_patchedChain = chain;

        // Keep the dummy window alive so the swapchain (and the patched vtable)
        // stays valid; it is never shown.
        ShowWindow(dummyWnd, SW_HIDE);
        return true;
    }
}

namespace
{
    DWORD WINAPI UnloadThread(LPVOID)
    {
        // Give the current Present frame time to return through our hook so we
        // don't unlink ourselves mid-call.
        Sleep(500);

        RequestMainThreadExit();
        WaitForMainThreadExit();

        UnhookVtable();
        UnhookWndProc();
        ShutdownImGui();

        FreeLibraryAndExitThread(g_hModule, 0);
        return 0;
    }
}

namespace DX11Hook
{
    void RequestUnload()
    {
        if (g_unloadRequested)
            return;
        g_unloadRequested = true;
        CreateThread(nullptr, 0, UnloadThread, nullptr, 0, nullptr);
    }
}
