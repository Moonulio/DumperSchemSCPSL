#pragma once

#include <string>
#include <vector>
#include "il2cpp.h"

// ---------------------------------------------------------------------------
// SCP:SL game SDK surface. Class/method/field names are resolved at runtime so
// the same code works across game updates as long as the managed names stay
// the same. The types below mirror what the game's Assembly-CSharp exposes.
// ---------------------------------------------------------------------------

// PlayerRoles.RoleColor (value type, 16 bytes).
struct RoleColor {
    float r, g, b, a;
};

// AdminToys.PrimitiveType (Unity primitive order in current versions)
enum class PrimitiveType : int {
    Sphere   = 0,
    Capsule  = 1,
    Cylinder = 2,
    Cube     = 3,
    Plane    = 4,
    Quad     = 5,
};

// AdminToys.PrimitiveFlags
enum PrimitiveFlags : int {
    PrimitiveFlag_None       = 0,
    PrimitiveFlag_Collidable = 1,
    PrimitiveFlag_Visible    = 2,
};

// Opaque UnityEngine.Object handle used for "any" game object.
struct Object {};

struct Renderer;
struct Material;

// View over the game's Dictionary<RoleColor, Material> CachedMaterials.
struct RoleColorArray;
struct MaterialArray;
struct CachedMaterialsView {
    void*             dict = nullptr;
    Il2CppArray*      entries = nullptr;
    int               count = 0;
    size_t            entrySize = 0;
    size_t            keyOffset = 0;
    size_t            valueOffset = 0;

    static CachedMaterialsView From(void* dictObject);

    size_t  get_Count()  const { return (size_t)(count < 0 ? 0 : count); }
    RoleColor get_Key(size_t i)  const;
    void*   get_Value(size_t i) const;
    RoleColorArray get_Keys()   const;
    MaterialArray  get_Values() const;
};

struct RoleColorArray {
    const CachedMaterialsView* owner = nullptr;
    RoleColor operator[](size_t i) const { return owner->get_Key(i); }
};

struct MaterialArray {
    const CachedMaterialsView* owner = nullptr;
    void* operator[](size_t i) const { return owner->get_Value(i); }
};

// AdminToys.PrimitiveObjectToy
struct PrimitiveObjectToy {
    int GetFlags() const;
    Renderer* GetRenderer() const;
    static CachedMaterialsView* GetCachedMaterials();
};

struct Renderer {
    Material* GetMaterial() const;
};

struct Material {
    void* GetColorRaw() const;      // returns pointer to UnityEngine.Color
};

// Cached game class handles (filled by SCPSL::Init()).
namespace SCPSL
{
    extern Il2CppClass* PrimitiveObjectToy_Class;
    extern Il2CppClass* LightSourceToy_Class;
    extern Il2CppClass* TextToy_Class;
    extern Il2CppClass* AdminToyBase_Class;
    extern Il2CppClass* MapEditor_Class;
    extern Il2CppClass* Object_Class;
    extern Il2CppClass* Renderer_Class;
    extern Il2CppClass* Material_Class;
    extern Il2CppClass* Transform_Class;
    extern Il2CppClass* Component_Class;
    extern Il2CppClass* Light_Class;
    extern Il2CppClass* TextMesh_Class;
    extern Il2CppClass* Application_Class;
    extern Il2CppClass* Cursor_Class;
    extern Il2CppClass* ItemPickupBase_Class;
    extern Il2CppClass* PickupSyncInfo_Class;
    extern Il2CppClass* FirearmPickup_Class;
}

// User-provided helpers (kept intact, implemented in schematic_dumper.cpp).
RoleColor GetColorFromPrimitive(PrimitiveObjectToy* primitive);
std::string GetName(PrimitiveType type);
std::string to_uppercase(const std::string& s);

// ---------------------------------------------------------------------------
// Helpers used by the dumper.
// ---------------------------------------------------------------------------
namespace SCPSL
{
    struct Vector3 { float x, y, z; };
    struct Color   { float r, g, b, a; };

    struct PrimitiveData {
        std::string name;
        std::string typeName;
        int type = -1;
        int flags = -1;
        bool isStatic = false;
        int parentId = 0;
        int objectId = 0;
        Vector3 pos{}, rot{}, scale{};
        Color color{ -1, -1, -1, -1 };
        Color baseColor{ -1, -1, -1, -1 };
    };

    struct LightData {
        std::string name;
        Vector3 pos{}, rot{}, scale{};
        Color color{ -1, -1, -1, -1 };
        float range = 0.f;
        float intensity = 0.f;
        bool isStatic = false;
        int parentId = 0;
        int objectId = 0;
        int lightType = -1;
        int shadowType = -1;
        float shadowStrength = 0.f;
        float spotAngle = 0.f;
        float innerSpotAngle = 0.f;
    };

    struct TextData {
        std::string name;
        Vector3 pos{}, rot{}, scale{};
        std::string text;
        float displayWidth = 0.f;
        float displayHeight = 0.f;
        bool isStatic = false;
        int parentId = 0;
        int objectId = 0;
    };

    struct PickupData {
        std::string name;
        Vector3 pos{}, rot{}, scale{};
        int objectId = 0;
        int parentId = 0;
        int itemType = 0;       // ItemType enum value
        uint32_t serial = 0;    // item serial
        std::string attachmentsCode;
        int uses = 1;
        bool isStatic = false;
        bool isLocked = false;
        bool inUse = false;
    };

    // Resolve all game classes. Call once after API::Initialize().
    bool Init();

    // All PrimitiveObjectToy / LightSourceToy / TextToy / ItemPickupBase currently loaded in the world.
    std::vector<void*> FindAllPrimitives();
    std::vector<void*> FindAllLights();
    std::vector<void*> FindAllTexts();
    std::vector<void*> FindAllPickups();

    PrimitiveData ReadPrimitive(void* obj);
    LightData     ReadLight(void* obj);
    TextData      ReadText(void* obj);
    PickupData    ReadPickup(void* obj);

    // Transform helpers used to filter schematic pickups from world items.
    void* GetComponentTransform(void* obj, Il2CppClass* cls);
    void* TransformGetParent(void* tr);

    std::string GameVersion();

    // Diagnostics: returns a text report (assemblies, class resolutions,
    // Assembly-CSharp classes matching schematic-related keywords).
    std::string DebugDump();

    // Unlocks the mouse cursor while the menu is open.
    void ForceUnlockCursor();
}
