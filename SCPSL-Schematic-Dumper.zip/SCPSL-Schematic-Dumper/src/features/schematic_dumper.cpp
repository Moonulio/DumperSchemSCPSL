#include "schematic_dumper.h"
#include "../utils/json.h"
#include "../utils/file.h"
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <ctime>
#include <map>
#include <set>

// ---------------------------------------------------------------------------
// Global object lists (as in the original snippet).
// ---------------------------------------------------------------------------
std::vector<PrimitiveObjectToy*> primitivesls;
std::vector<Object*> Lights;
std::vector<void*> Texts;
std::vector<void*> Pickups;

namespace SchematicDumper
{
    // Progressive (incremental) collection state.
    bool Collecting = false;
}

// ---------------------------------------------------------------------------
// Original snippet helpers, kept intact.
// ---------------------------------------------------------------------------

int GetPrimitiveFlags(PrimitiveObjectToy* primitive)
{
    int flags = primitive->GetFlags();
    if (flags & PrimitiveFlag_Visible)
        return PrimitiveFlag_Visible;
    return PrimitiveFlag_Visible | PrimitiveFlag_Collidable;
}

std::string GetName(PrimitiveType type)
{
    if (type == PrimitiveType::Sphere)
        return "Sphere";
    else if (type == PrimitiveType::Capsule)
        return "Capsule";
    else if (type == PrimitiveType::Cylinder)
        return "Cylinder";
    else if (type == PrimitiveType::Cube)
        return "Cube";
    else if (type == PrimitiveType::Plane)
        return "Plane";
    else if (type == PrimitiveType::Quad)
        return "Quad";
    return "";
}

RoleColor GetColorFromPrimitive(PrimitiveObjectToy* primitive)
{
    if (!primitive) return { -1, -1, -1, -1 };

    auto idk = PrimitiveObjectToy::GetCachedMaterials();
    Renderer* rend = primitive->GetRenderer();
    if (!rend) return { -1, -1, -1, -1 };
    Material* matt = rend->GetMaterial();
    if (!matt) return { -1, -1, -1, -1 };

    for (size_t i = 0; i < idk->get_Count(); i++) {
        RoleColor key   = idk->get_Keys()[i];
        void*     value = idk->get_Values()[i];
        if (value == matt) {
            return key;
        }
    }
    return { -1, -1, -1, -1 };
}

std::string to_uppercase(const std::string& s)
{
    std::string result = s;
    std::transform(result.begin(), result.end(), result.begin(), ::toupper);
    return result;
}

// ---------------------------------------------------------------------------
// Exporter
// ---------------------------------------------------------------------------

namespace
{
    std::string NowUtc()
    {
        time_t t = time(nullptr);
        struct tm tmv;
        gmtime_s(&tmv, &t);
        char buf[32];
        strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", &tmv);
        return buf;
    }

    std::string ColorHex(const SCPSL::Color& c)
    {
        if (c.r < 0.f) return "FFFFFFFF";
        auto toByte = [](float f) {
            int v = (int)(f * 255.0f + 0.5f);
            if (v < 0) v = 0;
            if (v > 255) v = 255;
            return v;
        };
        char buf[16];
        snprintf(buf, sizeof(buf), "%02X%02X%02X%02X",
                 toByte(c.r), toByte(c.g), toByte(c.b), toByte(c.a));
        return buf;
    }

    void WriteVec3(JsonWriter& j, const SCPSL::Vector3& v)
    {
        j.BeginObject();
        j.Key("x"); j.ValueDouble(v.x, 6);
        j.Key("y"); j.ValueDouble(v.y, 6);
        j.Key("z"); j.ValueDouble(v.z, 6);
        j.EndObject();
    }

    void WriteVec2(JsonWriter& j, float x, float y)
    {
        j.BeginObject();
        j.Key("x"); j.ValueDouble(x, 6);
        j.Key("y"); j.ValueDouble(y, 6);
        j.EndObject();
    }

    void WritePrimitiveProperties(JsonWriter& j, const SCPSL::PrimitiveData& d)
    {
        j.BeginObject();
        j.Key("PrimitiveType");  j.ValueInt(d.type);
        j.Key("Color");          j.ValueString(ColorHex(d.color));
        j.Key("PrimitiveFlags"); j.ValueInt(d.flags);
        j.Key("Static");         j.ValueBool(d.isStatic);
        j.EndObject();
    }

    void WriteLightProperties(JsonWriter& j, const SCPSL::LightData& d)
    {
        j.BeginObject();
        j.Key("LightType");       j.ValueInt(d.lightType);
        j.Key("Color");           j.ValueString(ColorHex(d.color));
        j.Key("Intensity");       j.ValueDouble(d.intensity, 6);
        j.Key("Range");           j.ValueDouble(d.range, 6);
        j.Key("Shape");           j.ValueInt(0);
        j.Key("SpotAngle");       j.ValueDouble(d.spotAngle, 6);
        j.Key("InnerSpotAngle");  j.ValueDouble(d.innerSpotAngle, 6);
        j.Key("ShadowStrength");  j.ValueDouble(d.shadowStrength, 6);
        j.Key("ShadowType");      j.ValueInt(d.shadowType);
        j.Key("Static");          j.ValueBool(d.isStatic);
        j.EndObject();
    }

    void WritePickupProperties(JsonWriter& j, const SCPSL::PickupData& d)
    {
        j.BeginObject();
        j.Key("ItemType");        j.ValueInt(d.itemType);
        j.Key("CustomItem");      j.ValueString("");
        j.Key("AttachmentsCode"); j.ValueString(d.attachmentsCode.empty() ? "-1" : d.attachmentsCode);
        j.Key("Chance");          j.ValueDouble(100.0, 1);
        j.Key("Uses");            j.ValueInt(d.uses);
        j.Key("Static");          j.ValueBool(d.isStatic);
        j.EndObject();
    }

    // Unique display name per base type, matching the reference format:
    // "Sphere", "Sphere (1)", "Sphere (2)", ... The Unity loader switches on
    // the block name, so the base name must be exactly the primitive type.
    std::string UniqueName(std::map<std::string, int>& counts, const std::string& base)
    {
        int n = counts[base]++;
        if (n == 0)
            return base;
        return base + " (" + std::to_string(n) + ")";
    }

    // Returns true if the pickup's transform (or any of its parents) is part of
    // the schematic hierarchy. The plugin parents schematic pickups under the
    // schematic root or a schematic block, while world loot/player items live
    // under their own GameObjects, so walking the parent chain filters them out.
    bool PickupBelongsToSchematic(void* pickup, const std::set<void*>& schematicTransforms)
    {
        void* tr = SCPSL::GetComponentTransform(pickup, SCPSL::ItemPickupBase_Class);
        for (int i = 0; tr && i < 64; i++) {
            if (schematicTransforms.count(tr) != 0)
                return true;
            tr = SCPSL::TransformGetParent(tr);
        }
        return false;
    }

    // Builds the set of transforms that make up the schematic hierarchy:
    // every block transform plus every one of its ancestors (up to a depth),
    // so the schematic root is always covered regardless of parenting depth.
    template <typename TPrims, typename TLights, typename TTexts>
    void CollectSchematicTransforms(const TPrims& prims,
                                    const TLights& lights,
                                    const TTexts& texts,
                                    std::set<void*>& out)
    {
        auto addChain = [&](void* obj, Il2CppClass* cls) {
            void* tr = SCPSL::GetComponentTransform(obj, cls);
            for (int i = 0; tr && i < 32; i++) {
                out.insert(tr);
                tr = SCPSL::TransformGetParent(tr);
            }
        };
        for (auto p : prims)  addChain(p, SCPSL::PrimitiveObjectToy_Class);
        for (auto p : lights) addChain(p, SCPSL::LightSourceToy_Class);
        for (auto p : texts)  addChain(p, SCPSL::TextToy_Class);
    }

    // ---------------------------------------------------------------------------
    // Progressive (incremental) capture.
    //
    // Some servers run an optimisation plugin that hides schematic parts and
    // spawns them lazily as the player approaches. A single snapshot then comes
    // back incomplete. These helpers keep collecting newly-appeared blocks while
    // the player walks around, deduplicating by position+type, until Stop saves
    // the accumulated set to the schematic json.
    // ---------------------------------------------------------------------------

    struct IncState {
        std::vector<SCPSL::PrimitiveData> prims;
        std::vector<SCPSL::LightData>     lights;
        std::vector<SCPSL::TextData>      texts;
        std::vector<SCPSL::PickupData>    pickups;
        std::vector<void*>                primObjs;
        std::vector<void*>                lightObjs;
        std::vector<void*>                textObjs;
        std::vector<void*>                pickupObjs;
        std::set<void*>                   seenPrim;
        std::set<void*>                   seenLight;
        std::set<void*>                   seenText;
        std::set<void*>                   seenPickup;
    };
    static IncState g_inc;

    void IncReset()
    {
        g_inc.prims.clear();
        g_inc.lights.clear();
        g_inc.texts.clear();
        g_inc.pickups.clear();
        g_inc.primObjs.clear();
        g_inc.lightObjs.clear();
        g_inc.textObjs.clear();
        g_inc.pickupObjs.clear();
        g_inc.seenPrim.clear();
        g_inc.seenLight.clear();
        g_inc.seenText.clear();
        g_inc.seenPickup.clear();
    }

    void IncrementalTick()
    {
        if (!SchematicDumper::Collecting)
            return;
        API::il2cpp_thread_attach(domain);

        if (SchematicDumper::CollectPrimitives) {
            for (void* p : SCPSL::FindAllPrimitives()) {
                SCPSL::PrimitiveData d = SCPSL::ReadPrimitive(p);
                if (d.flags == 0)
                    continue; // anchor spheres
                if (!g_inc.seenPrim.insert(p).second)
                    continue; // same Unity object already added
                g_inc.prims.push_back(d);
                g_inc.primObjs.push_back(p);
            }
        }

        if (SchematicDumper::CollectLights) {
            for (void* p : SCPSL::FindAllLights()) {
                SCPSL::LightData d = SCPSL::ReadLight(p);
                if (d.parentId == 0)
                    continue; // map / SL lighting
                if (!g_inc.seenLight.insert(p).second)
                    continue;
                g_inc.lights.push_back(d);
                g_inc.lightObjs.push_back(p);
            }
        }

        if (SchematicDumper::CollectTexts) {
            for (void* p : SCPSL::FindAllTexts()) {
                SCPSL::TextData d = SCPSL::ReadText(p);
                if (d.parentId == 0)
                    continue;
                if (!g_inc.seenText.insert(p).second)
                    continue;
                g_inc.texts.push_back(d);
                g_inc.textObjs.push_back(p);
            }
        }

        if (SchematicDumper::CollectPickups) {
            for (void* p : SCPSL::FindAllPickups()) {
                if (!g_inc.seenPickup.insert(p).second)
                    continue;
                g_inc.pickupObjs.push_back(p);
                g_inc.pickups.push_back(SCPSL::ReadPickup(p));
            }
        }

        SchematicDumper::LastPrimitiveCount = (int)g_inc.prims.size();
        SchematicDumper::LastLightCount     = (int)g_inc.lights.size();
    }

    // Fills the global lists with everything currently loaded on the server world.
    void CollectAllToys()
    {
        primitivesls.clear();
        Lights.clear();
        Texts.clear();
        Pickups.clear();

        if (SchematicDumper::CollectPrimitives)
            for (void* p : SCPSL::FindAllPrimitives())
                primitivesls.push_back((PrimitiveObjectToy*)p);
        if (SchematicDumper::CollectLights)
            for (void* p : SCPSL::FindAllLights())
                Lights.push_back((Object*)p);
        if (SchematicDumper::CollectTexts)
            for (void* p : SCPSL::FindAllTexts())
                Texts.push_back(p);
        if (SchematicDumper::CollectPickups)
            for (void* p : SCPSL::FindAllPickups())
                Pickups.push_back(p);
    }

    std::string CreateBlockFromSchematics(const std::string& fileName)
    {
        API::il2cpp_thread_attach(domain);

        CollectAllToys();

        SchematicDumper::LastPrimitiveCount = (int)primitivesls.size();
        SchematicDumper::LastLightCount     = (int)Lights.size();

        std::string desktop = FileUtils::GetDesktopPath();
        if (desktop.empty())
            return "ERROR: desktop folder not found";

        std::string folder = desktop + "\\SCPSL_Schematics";
        if (FileUtils::CreateFolder(folder).empty())
            return "ERROR: cannot create folder " + folder;

        std::string safe = FileUtils::SanitizeFileName(fileName);
        if (safe.empty())
            safe = "server_schematic";

        // Output layout: when the schematic contains pickups, save everything
        // into a folder named after the map (main json + Rigidbodies json).
        // Without pickups the file is saved directly in the schematics folder.
        std::string outDir = folder;
        if (!Pickups.empty())
            outDir = folder + "\\" + safe;
        std::string path = outDir + "\\" + safe + ".json";

        // Root of the schematic hierarchy: the most common parent id among
        // primitives. Map lighting (SL) is a separate LightSourceToy tree whose
        // parent id is 0, so it is excluded from the root search and export.
        long long rootId = 0;
        {
            long long bestId = 0;
            int bestCount = 0;
            std::map<long long, int> counts;
            auto addId = [&](int pid) {
                if (pid == 0) return;
                long long id = pid;
                counts[id]++;
                if (counts[id] > bestCount) { bestCount = counts[id]; bestId = id; }
            };
            for (void* p : primitivesls) addId(SCPSL::ReadPrimitive(p).parentId);
            if (bestCount == 0)
                for (void* p : Lights) addId(SCPSL::ReadLight(p).parentId);
            if (bestCount == 0)
                for (void* p : Texts) addId(SCPSL::ReadText(p).parentId);
            rootId = bestId;
        }

        // Keep only schematic lights: those with a real schematic parent.
        // Map/SL lights have no schematic parent (parentId 0).
        std::vector<void*> schematicLights;
        for (void* p : Lights) {
            SCPSL::LightData d = SCPSL::ReadLight(p);
            if (d.parentId != 0)
                schematicLights.push_back(p);
        }

        // Game-side net ids are unreliable here (GetInstanceID/netId return
        // identical values for all objects), and Unity keys the tree by
        // ObjectId. Generate unique, stable ids ourselves and attach every
        // block to the schematic root.
        long long nextId = 1000000;
        std::map<std::string, int> nameCounts;
        int exportedPrimitives = 0;

        JsonWriter j(true);
        j.BeginObject();
        j.Key("RootObjectId"); j.ValueInt(rootId);

        j.Key("Blocks");
        j.BeginArray();

        for (size_t i = 0; i < primitivesls.size(); i++) {
            SCPSL::PrimitiveData d = SCPSL::ReadPrimitive(primitivesls[i]);
            // Skip invisible placeholder/anchor spheres: in the game these have
            // PrimitiveFlags = 0 (neither Visible nor Collidable), unit scale
            // and white color. They are schematic anchors, not real blocks, and
            // the reference format never contains them (only flags 2 and 3).
            if (d.flags == 0)
                continue;
            exportedPrimitives++;
            std::string typeName = d.typeName.empty() ? "Cube" : d.typeName;
            j.BeginObject();
            j.Key("Name");       j.ValueString(UniqueName(nameCounts, typeName));
            j.Key("ObjectId");   j.ValueInt((int)nextId++);
            j.Key("ParentId");   j.ValueInt((int)rootId);
            j.Key("Position");   WriteVec3(j, d.pos);
            j.Key("Rotation");   WriteVec3(j, d.rot);
            j.Key("Scale");      WriteVec3(j, d.scale);
            j.Key("BlockType");  j.ValueInt(1);
            j.Key("Properties"); WritePrimitiveProperties(j, d);
            j.EndObject();
        }

        for (size_t i = 0; i < schematicLights.size(); i++) {
            SCPSL::LightData d = SCPSL::ReadLight(schematicLights[i]);
            SCPSL::Vector3 lscale = d.scale;
            if (lscale.x == 0.f && lscale.y == 0.f && lscale.z == 0.f) {
                lscale.x = lscale.y = lscale.z = 1.f;
            }
            j.BeginObject();
            j.Key("Name");       j.ValueString(UniqueName(nameCounts, "LightSource"));
            j.Key("ObjectId");   j.ValueInt((int)nextId++);
            j.Key("ParentId");   j.ValueInt((int)rootId);
            j.Key("Position");   WriteVec3(j, d.pos);
            j.Key("Rotation");   WriteVec3(j, d.rot);
            j.Key("Scale");      WriteVec3(j, lscale);
            j.Key("BlockType");  j.ValueInt(2);
            j.Key("Properties"); WriteLightProperties(j, d);
            j.EndObject();
        }

        for (size_t i = 0; i < Texts.size(); i++) {
            SCPSL::TextData d = SCPSL::ReadText(Texts[i]);
            if (d.parentId == 0)
                continue;
            j.BeginObject();
            j.Key("Name");       j.ValueString(UniqueName(nameCounts, "Text"));
            j.Key("ObjectId");   j.ValueInt((int)nextId++);
            j.Key("ParentId");   j.ValueInt((int)rootId);
            j.Key("Position");   WriteVec3(j, d.pos);
            j.Key("Rotation");   WriteVec3(j, d.rot);
            j.Key("Scale");      WriteVec3(j, d.scale);
            j.Key("BlockType");  j.ValueInt(8);
            j.Key("Properties");
            j.BeginObject();
            j.Key("Text");         j.ValueString(d.text.empty() ? "Text" : d.text);
            j.Key("DisplaySize");  WriteVec2(j, d.displayWidth, d.displayHeight);
            j.Key("Static");       j.ValueBool(d.isStatic);
            j.EndObject();
            j.EndObject();
        }

        // Pickup blocks. Only export pickups that belong to the schematic
        // hierarchy (parented under the schematic root or one of its blocks).
        // World loot / player-dropped items are excluded.
        std::set<void*> schematicTransforms;
        CollectSchematicTransforms(primitivesls, Lights, Texts, schematicTransforms);

        std::vector<void*> schematicPickups;
        if (!schematicTransforms.empty()) {
            for (void* p : Pickups)
                if (PickupBelongsToSchematic(p, schematicTransforms))
                    schematicPickups.push_back(p);
            if (schematicPickups.empty() && !Pickups.empty()) {
                // Filter matched nothing even though pickups exist — fall back
                // to exporting all of them rather than silently dropping every
                // pickup (discriminator too strict / hierarchy unresolved).
                schematicPickups = Pickups;
            }
        } else {
            // No schematic blocks found (or transform chain failed) — cannot
            // discriminate, keep every pickup so nothing is silently dropped.
            schematicPickups = Pickups;
        }

        std::map<int, std::string> pickupIds; // ObjectId -> string key for Rigidbodies file
        for (size_t i = 0; i < schematicPickups.size(); i++) {
            SCPSL::PickupData d = SCPSL::ReadPickup(schematicPickups[i]);
            int oid = (int)nextId++;
            pickupIds[oid] = std::to_string(oid);
            j.BeginObject();
            j.Key("Name");       j.ValueString(UniqueName(nameCounts, "Pickup"));
            j.Key("ObjectId");   j.ValueInt(oid);
            j.Key("ParentId");   j.ValueInt((int)rootId);
            j.Key("Position");   WriteVec3(j, d.pos);
            j.Key("Rotation");   WriteVec3(j, d.rot);
            j.Key("Scale");      WriteVec3(j, d.scale);
            j.Key("BlockType");  j.ValueInt(3);
            j.Key("Properties"); WritePickupProperties(j, d);
            j.EndObject();
        }

        j.EndArray();
        j.EndObject();

        if (outDir != folder && FileUtils::CreateFolder(outDir).empty())
            return "ERROR: cannot create folder " + outDir;

        if (!FileUtils::WriteTextFile(path, j.str()))
            return "ERROR: cannot write file " + path;

        // When pickups exist, write the matching Rigidbodies file next to the
        // schematic so Unity knows physics for the spawned pickups.
        std::string rbNote;
        if (!schematicPickups.empty()) {
            std::string rbPath = outDir + "\\" + safe + "-Rigidbodies.json";
            JsonWriter r(true);
            r.BeginObject();
            for (auto& kv : pickupIds) {
                r.Key(kv.second.c_str());
                r.BeginObject();
                r.Key("IsKinematic"); r.ValueBool(false);
                r.Key("UseGravity");  r.ValueBool(true);
                r.Key("Constraints"); r.ValueInt(0);
                r.Key("Mass");        r.ValueDouble(1.0, 1);
                r.EndObject();
            }
            r.EndObject();
            if (!FileUtils::WriteTextFile(rbPath, r.str()))
                rbNote = " (Rigidbodies WRITE FAILED)";
            else
                rbNote = " + Rigidbodies";
        }

        return "Saved: " + path + " (" + std::to_string(exportedPrimitives) +
               " primitives, " + std::to_string(schematicLights.size()) + " lights, " +
               std::to_string(Texts.size()) + " texts, " + std::to_string(schematicPickups.size()) +
               " pickups)" + rbNote;
    }
}

namespace SchematicDumper
{
    char Filename[128] = "server_schematic";
    std::string LastStatus;
    int LastPrimitiveCount = 0;
    int LastLightCount = 0;

    bool CollectPrimitives = true;
    bool CollectLights     = true;
    bool CollectTexts      = true;
    bool CollectPickups    = true;

    std::string Run(const std::string& fileName)
    {
        LastStatus = CreateBlockFromSchematics(fileName);
        return LastStatus;
    }

    // Starts progressive collection (can be called repeatedly, resets state).
    void StartCollection()
    {
        IncReset();
        Collecting = true;
        LastPrimitiveCount = 0;
        LastLightCount = 0;
        LastStatus = "Collecting... keep walking to reveal hidden blocks. Press Stop when done.";
    }

    // Stops collection and writes the accumulated set to <fileName>.json.
    std::string Stop(const std::string& fileName)
    {
        Collecting = false;

        std::string desktop = FileUtils::GetDesktopPath();
        if (desktop.empty())
            return "ERROR: desktop folder not found";

        std::string folder = desktop + "\\SCPSL_Schematics";
        if (FileUtils::CreateFolder(folder).empty())
            return "ERROR: cannot create folder " + folder;

        std::string safe = FileUtils::SanitizeFileName(fileName);
        if (safe.empty())
            safe = "server_schematic";

        // Output layout: with pickups -> folder named after the map.
        std::string outDir = folder;
        if (!g_inc.pickupObjs.empty())
            outDir = folder + "\\" + safe;
        std::string path = outDir + "\\" + safe + ".json";

        long long rootId = 0;
        {
            long long bestId = 0;
            int bestCount = 0;
            std::map<long long, int> counts;
            for (auto& d : g_inc.prims) {
                if (d.parentId == 0) continue;
                long long id = d.parentId;
                counts[id]++;
                if (counts[id] > bestCount) { bestCount = counts[id]; bestId = id; }
            }
            if (bestCount == 0)
                for (auto& d : g_inc.lights) {
                    if (d.parentId == 0) continue;
                    long long id = d.parentId;
                    counts[id]++;
                    if (counts[id] > bestCount) { bestCount = counts[id]; bestId = id; }
                }
            if (bestCount == 0)
                for (auto& d : g_inc.texts) {
                    if (d.parentId == 0) continue;
                    long long id = d.parentId;
                    counts[id]++;
                    if (counts[id] > bestCount) { bestCount = counts[id]; bestId = id; }
                }
            rootId = bestId;
        }

        // Filter pickups to those parented under the schematic hierarchy.
        std::set<void*> schematicTransforms;
        CollectSchematicTransforms(g_inc.primObjs, g_inc.lightObjs, g_inc.textObjs, schematicTransforms);

        std::vector<SCPSL::PickupData> schematicPickups;
        if (!schematicTransforms.empty()) {
            for (size_t i = 0; i < g_inc.pickupObjs.size(); i++)
                if (PickupBelongsToSchematic(g_inc.pickupObjs[i], schematicTransforms))
                    schematicPickups.push_back(g_inc.pickups[i]);
            if (schematicPickups.empty() && !g_inc.pickups.empty())
                schematicPickups = g_inc.pickups;
        } else {
            schematicPickups = g_inc.pickups;
        }

        long long nextId = 1000000;
        std::map<std::string, int> nameCounts;
        int exportedPrimitives = 0;

        JsonWriter j(true);
        j.BeginObject();
        j.Key("RootObjectId"); j.ValueInt(rootId);
        j.Key("Blocks");
        j.BeginArray();

        for (auto& d : g_inc.prims) {
            exportedPrimitives++;
            std::string typeName = d.typeName.empty() ? "Cube" : d.typeName;
            j.BeginObject();
            j.Key("Name");       j.ValueString(UniqueName(nameCounts, typeName));
            j.Key("ObjectId");   j.ValueInt((int)nextId++);
            j.Key("ParentId");   j.ValueInt((int)rootId);
            j.Key("Position");   WriteVec3(j, d.pos);
            j.Key("Rotation");   WriteVec3(j, d.rot);
            j.Key("Scale");      WriteVec3(j, d.scale);
            j.Key("BlockType");  j.ValueInt(1);
            j.Key("Properties"); WritePrimitiveProperties(j, d);
            j.EndObject();
        }

        for (auto& d : g_inc.lights) {
            SCPSL::Vector3 lscale = d.scale;
            if (lscale.x == 0.f && lscale.y == 0.f && lscale.z == 0.f)
                lscale.x = lscale.y = lscale.z = 1.f;
            j.BeginObject();
            j.Key("Name");       j.ValueString(UniqueName(nameCounts, "LightSource"));
            j.Key("ObjectId");   j.ValueInt((int)nextId++);
            j.Key("ParentId");   j.ValueInt((int)rootId);
            j.Key("Position");   WriteVec3(j, d.pos);
            j.Key("Rotation");   WriteVec3(j, d.rot);
            j.Key("Scale");      WriteVec3(j, lscale);
            j.Key("BlockType");  j.ValueInt(2);
            j.Key("Properties"); WriteLightProperties(j, d);
            j.EndObject();
        }

        for (auto& d : g_inc.texts) {
            j.BeginObject();
            j.Key("Name");       j.ValueString(UniqueName(nameCounts, "Text"));
            j.Key("ObjectId");   j.ValueInt((int)nextId++);
            j.Key("ParentId");   j.ValueInt((int)rootId);
            j.Key("Position");   WriteVec3(j, d.pos);
            j.Key("Rotation");   WriteVec3(j, d.rot);
            j.Key("Scale");      WriteVec3(j, d.scale);
            j.Key("BlockType");  j.ValueInt(8);
            j.Key("Properties");
            j.BeginObject();
            j.Key("Text");         j.ValueString(d.text.empty() ? "Text" : d.text);
            j.Key("DisplaySize");  WriteVec2(j, d.displayWidth, d.displayHeight);
            j.Key("Static");       j.ValueBool(d.isStatic);
            j.EndObject();
            j.EndObject();
        }

        // Pickup blocks.
        std::map<int, std::string> pickupIds;
        for (size_t i = 0; i < schematicPickups.size(); i++) {
            SCPSL::PickupData& d = schematicPickups[i];
            int oid = (int)nextId++;
            pickupIds[oid] = std::to_string(oid);
            j.BeginObject();
            j.Key("Name");       j.ValueString(UniqueName(nameCounts, "Pickup"));
            j.Key("ObjectId");   j.ValueInt(oid);
            j.Key("ParentId");   j.ValueInt((int)rootId);
            j.Key("Position");   WriteVec3(j, d.pos);
            j.Key("Rotation");   WriteVec3(j, d.rot);
            j.Key("Scale");      WriteVec3(j, d.scale);
            j.Key("BlockType");  j.ValueInt(3);
            j.Key("Properties"); WritePickupProperties(j, d);
            j.EndObject();
        }

        j.EndArray();
        j.EndObject();

        if (outDir != folder && FileUtils::CreateFolder(outDir).empty())
            return "ERROR: cannot create folder " + outDir;

        if (!FileUtils::WriteTextFile(path, j.str()))
            return "ERROR: cannot write file " + path;

        std::string rbNote;
        if (!schematicPickups.empty()) {
            std::string rbPath = outDir + "\\" + safe + "-Rigidbodies.json";
            JsonWriter r(true);
            r.BeginObject();
            for (auto& kv : pickupIds) {
                r.Key(kv.second.c_str());
                r.BeginObject();
                r.Key("IsKinematic"); r.ValueBool(false);
                r.Key("UseGravity");  r.ValueBool(true);
                r.Key("Constraints"); r.ValueInt(0);
                r.Key("Mass");        r.ValueDouble(1.0, 1);
                r.EndObject();
            }
            r.EndObject();
            if (!FileUtils::WriteTextFile(rbPath, r.str()))
                rbNote = " (Rigidbodies WRITE FAILED)";
            else
                rbNote = " + Rigidbodies";
        }

        LastStatus = "Saved: " + path + " (" + std::to_string(exportedPrimitives) +
                     " primitives, " + std::to_string(g_inc.lights.size()) + " lights, " +
                     std::to_string(g_inc.texts.size()) + " texts, " +
                     std::to_string(schematicPickups.size()) + " pickups)" + rbNote;
        return LastStatus;
    }

    // Called every frame from the render hook while Collecting is true.
    void Tick()
    {
        IncrementalTick();
    }
}
