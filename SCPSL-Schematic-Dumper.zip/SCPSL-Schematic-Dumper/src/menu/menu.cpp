#include "menu.h"
#include "../features/schematic_dumper.h"
#include "../sdk/scpsl.h"
#include "../hooks/dx11hook.h"
#include "../utils/file.h"
#include "imgui.h"

namespace Menu
{
    bool Opened = false;
    static bool s_debugWritten = false;
}

static void DrawSchematicSection()
{
    ImGui::Separator();
    ImGui::TextUnformatted("Schematic Dumper");

    ImGui::TextUnformatted("Scan:");
    ImGui::Checkbox("Primitives", &SchematicDumper::CollectPrimitives);
    ImGui::SameLine();
    ImGui::Checkbox("Lights", &SchematicDumper::CollectLights);
    ImGui::Checkbox("Texts", &SchematicDumper::CollectTexts);
    ImGui::SameLine();
    ImGui::Checkbox("Pickups", &SchematicDumper::CollectPickups);

    ImGui::SetNextItemWidth(-1.0f);
    ImGui::InputText("##filename", SchematicDumper::Filename, sizeof(SchematicDumper::Filename));

    if (ImGui::Button("Download schematic from server", ImVec2(-1.0f, 0.0f))) {
        SchematicDumper::Run(SchematicDumper::Filename);
    }
    ImGui::SameLine();
    ImGui::TextDisabled("(.json)");

    ImGui::Separator();
    ImGui::TextUnformatted("Progressive capture (hidden-optimised servers)");

    if (SchematicDumper::Collecting) {
        if (ImGui::Button("Stop and save collected schematic", ImVec2(-1.0f, 0.0f))) {
            SchematicDumper::Stop(SchematicDumper::Filename);
        }
        ImGui::Text("Collecting... %d primitives so far", SchematicDumper::LastPrimitiveCount);
    } else {
        if (ImGui::Button("Start progressive capture", ImVec2(-1.0f, 0.0f))) {
            SchematicDumper::StartCollection();
        }
    }
    ImGui::TextWrapped("Press Start, then walk around the schematic so hidden blocks spawn, then Stop to save all of it into the json.");

    ImGui::Separator();

    if (ImGui::Button("Dump debug info to Desktop", ImVec2(-1.0f, 0.0f))) {
        std::string folder = FileUtils::GetDesktopPath() + "\\SCPSL_Schematics";
        FileUtils::CreateFolder(folder);
        std::string path = folder + "\\debug.txt";
        Menu::s_debugWritten = FileUtils::WriteTextFile(path, SCPSL::DebugDump());
    }
    ImGui::SameLine();
    ImGui::TextDisabled(Menu::s_debugWritten ? "OK -> Desktop\\SCPSL_Schematics\\debug.txt" : "");

    ImGui::Text("Found: %d primitives, %d lights",
                SchematicDumper::LastPrimitiveCount,
                SchematicDumper::LastLightCount);

    if (!SchematicDumper::LastStatus.empty())
        ImGui::TextWrapped("%s", SchematicDumper::LastStatus.c_str());

    ImGui::TextDisabled("Saves to Desktop\\SCPSL_Schematics\\<name>.json");
    ImGui::TextDisabled("Menu key: INSERT");

    if (ImGui::Button("Unload DLL", ImVec2(-1.0f, 0.0f))) {
        DX11Hook::RequestUnload();
    }
    ImGui::TextDisabled("Unloads the mod (menu disappears). Safe to re-inject later.");
}

void Menu::Render()
{
    ImGui::SetNextWindowSize(ImVec2(430.0f, 0.0f), ImGuiCond_FirstUseEver);
    ImGui::Begin("SCPSL Schematic Dumper");
    DrawSchematicSection();
    ImGui::Separator();
    ImGui::Text("FPS: %.1f", ImGui::GetIO().Framerate);
    ImGui::End();
}

void Menu::Toggle()
{
    Opened = !Opened;
}
