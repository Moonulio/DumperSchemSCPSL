#pragma once

#include <string>

// Minimal dependency-free JSON writer.
class JsonWriter
{
public:
    JsonWriter(bool pretty = true);

    void BeginObject();
    void EndObject();
    void BeginArray();
    void EndArray();
    void Key(const char* key);

    void ValueString(const std::string& v);
    void ValueInt(long long v);
    void ValueDouble(double v, int decimals = 4);
    void ValueBool(bool v);

    std::string str() const { return b_; }

private:
    void ItemPrefix();
    void Indent();

    std::string b_;
    int depth_ = 0;
    bool firstItem_ = true;   // nothing written yet in the current container
    bool expectValue_ = false; // a key was just written, a value is expected inline
    bool pretty_ = true;
};
