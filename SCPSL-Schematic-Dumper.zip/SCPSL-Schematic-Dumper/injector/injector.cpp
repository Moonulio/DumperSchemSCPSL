#include <windows.h>
#include <tlhelp32.h>
#include <cstdio>
#include <string>
#include <vector>
#include <cstdint>

static DWORD FindProcessByName(const wchar_t* name)
{
    DWORD pid = 0;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE)
        return 0;
    PROCESSENTRY32W pe;
    pe.dwSize = sizeof(pe);
    if (Process32FirstW(snap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, name) == 0) {
                pid = pe.th32ProcessID;
                break;
            }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

static std::string ReadTargetString(HANDLE proc, uintptr_t addr)
{
    char buf[512] = {};
    SIZE_T rd = 0;
    if (!ReadProcessMemory(proc, (LPCVOID)addr, buf, sizeof(buf) - 1, &rd))
        return {};
    buf[rd] = 0;
    return std::string(buf);
}

static bool ManualMap(HANDLE proc, const std::string& dllPath, DWORD& outExit)
{
    HANDLE f = CreateFileA(dllPath.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr,
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) {
        std::printf("[!] Cannot open DLL file (err=%lu)\n", GetLastError());
        return false;
    }
    DWORD fileSize = GetFileSize(f, nullptr);
    std::vector<BYTE> buf(fileSize);
    DWORD read = 0;
    ReadFile(f, buf.data(), fileSize, &read, nullptr);
    CloseHandle(f);

    IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)buf.data();
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) {
        std::printf("[!] Not a valid PE (bad DOS header)\n");
        return false;
    }
    IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)(buf.data() + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE ||
        nt->FileHeader.Machine != IMAGE_FILE_MACHINE_AMD64 ||
        nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC) {
        std::printf("[!] Not a valid x64 PE\n");
        return false;
    }

    DWORD sizeOfImage = nt->OptionalHeader.SizeOfImage;
    DWORD sizeOfHeaders = nt->OptionalHeader.SizeOfHeaders;
    IMAGE_SECTION_HEADER* sections = IMAGE_FIRST_SECTION(nt);
    WORD numSections = nt->FileHeader.NumberOfSections;
    uintptr_t imageBase = (uintptr_t)nt->OptionalHeader.ImageBase;
    uintptr_t entryRVA = nt->OptionalHeader.AddressOfEntryPoint;

    BYTE* base = (BYTE*)VirtualAllocEx(proc, nullptr, sizeOfImage,
        MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!base) {
        std::printf("[!] VirtualAllocEx failed (err=%lu)\n", GetLastError());
        return false;
    }

    if (!WriteProcessMemory(proc, base, buf.data(), sizeOfHeaders, nullptr)) {
        std::printf("[!] WriteProcessMemory(headers) failed (err=%lu)\n", GetLastError());
        return false;
    }

    for (WORD i = 0; i < numSections; i++) {
        BYTE* dst = base + sections[i].VirtualAddress;
        if (sections[i].SizeOfRawData)
            WriteProcessMemory(proc, dst, buf.data() + sections[i].PointerToRawData,
                sections[i].SizeOfRawData, nullptr);
    }

    int64_t delta = (int64_t)((uintptr_t)base - imageBase);

    IMAGE_DATA_DIRECTORY relocDir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];
    if (delta != 0 && relocDir.VirtualAddress) {
        uintptr_t end = (uintptr_t)base + relocDir.VirtualAddress + relocDir.Size;
        BYTE* blockAddr = base + relocDir.VirtualAddress;
        while ((uintptr_t)blockAddr < end) {
            IMAGE_BASE_RELOCATION block;
            SIZE_T rb = 0;
            if (!ReadProcessMemory(proc, blockAddr, &block, sizeof(block), &rb) || !block.SizeOfBlock)
                break;
            DWORD numEntries = (block.SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / sizeof(WORD);
            for (DWORD n = 0; n < numEntries; n++) {
                WORD entry = 0;
                ReadProcessMemory(proc, blockAddr + sizeof(IMAGE_BASE_RELOCATION) + n * sizeof(WORD),
                    &entry, sizeof(entry), nullptr);
                WORD type = (WORD)(entry >> 12);
                WORD offset = (WORD)(entry & 0xFFF);
                if (type == IMAGE_REL_BASED_DIR64) {
                    uintptr_t val = 0;
                    uintptr_t where = (uintptr_t)base + block.VirtualAddress + offset;
                    if (ReadProcessMemory(proc, (LPCVOID)where, &val, sizeof(val), nullptr)) {
                        val += (uintptr_t)delta;
                        WriteProcessMemory(proc, (LPVOID)where, &val, sizeof(val), nullptr);
                    }
                }
            }
            blockAddr += block.SizeOfBlock;
        }
    }

    IMAGE_DATA_DIRECTORY impDir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (impDir.VirtualAddress) {
        IMAGE_IMPORT_DESCRIPTOR desc;
        SIZE_T rb = 0;
        uintptr_t impAddr = (uintptr_t)base + impDir.VirtualAddress;
        while (ReadProcessMemory(proc, (LPCVOID)impAddr, &desc, sizeof(desc), &rb) && desc.Name) {
            std::string dllName = ReadTargetString(proc, (uintptr_t)base + desc.Name);
            if (dllName.empty()) {
                std::printf("[!] Empty import DLL name\n");
                return false;
            }
            HMODULE hMod = LoadLibraryA(dllName.c_str());
            if (!hMod) {
                hMod = LoadLibraryA(("C:\\Windows\\System32\\" + dllName).c_str());
            }
            if (!hMod) {
                std::printf("[!] Cannot load '%s' for imports (err=%lu)\n", dllName.c_str(), GetLastError());
                return false;
            }

            uintptr_t origThunkAddr = desc.OriginalFirstThunk
                ? (uintptr_t)base + desc.OriginalFirstThunk
                : (uintptr_t)base + desc.FirstThunk;
            uintptr_t thunkAddr = (uintptr_t)base + desc.FirstThunk;

            for (int idx = 0;; idx++) {
                uintptr_t thunkVal = 0;
                if (!ReadProcessMemory(proc, (LPCVOID)(origThunkAddr + idx * 8), &thunkVal, 8, nullptr))
                    break;
                if (!thunkVal)
                    break;

                uintptr_t resolved = 0;
                if (thunkVal & IMAGE_ORDINAL_FLAG64) {
                    resolved = (uintptr_t)GetProcAddress(hMod, (LPCSTR)(thunkVal & 0xFFFF));
                } else {
                    std::string name = ReadTargetString(proc, (uintptr_t)base + thunkVal + 2);
                    resolved = (uintptr_t)GetProcAddress(hMod, name.c_str());
                }
                if (!resolved) {
                    std::printf("[!] Cannot resolve import in '%s'\n", dllName.c_str());
                    return false;
                }
                WriteProcessMemory(proc, (LPVOID)(thunkAddr + idx * 8), &resolved, 8, nullptr);
            }
            impAddr += sizeof(desc);
        }
    }

    DWORD oldProt = 0;
    for (WORD i = 0; i < numSections; i++) {
        DWORD prot = PAGE_READONLY;
        DWORD chars = sections[i].Characteristics;
        if (chars & IMAGE_SCN_MEM_EXECUTE)
            prot = (chars & IMAGE_SCN_MEM_WRITE) ? PAGE_EXECUTE_READWRITE : PAGE_EXECUTE_READ;
        else if (chars & IMAGE_SCN_MEM_WRITE)
            prot = PAGE_READWRITE;
        DWORD secSize = sections[i].SizeOfRawData;
        if (sections[i].Misc.VirtualSize > secSize)
            secSize = sections[i].Misc.VirtualSize;
        VirtualProtectEx(proc, base + sections[i].VirtualAddress, secSize, prot, &oldProt);
    }
    VirtualProtectEx(proc, base, sizeOfHeaders, PAGE_READONLY, &oldProt);

    BYTE stub[41] = {
        0x48, 0xB9, 0,0,0,0,0,0,0,0,
        0xBA, 0x01, 0x00, 0x00, 0x00,
        0x45, 0x33, 0xC0,
        0x48, 0x83, 0xEC, 0x28,
        0x48, 0xB8, 0,0,0,0,0,0,0,0,
        0xFF, 0xD0,
        0x48, 0x83, 0xC4, 0x28,
        0x33, 0xC9,
        0xC3
    };
    *(uintptr_t*)(stub + 2) = (uintptr_t)base;
    *(uintptr_t*)(stub + 24) = (uintptr_t)base + entryRVA;

    BYTE* stubMem = (BYTE*)VirtualAllocEx(proc, nullptr, sizeof(stub),
        MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!stubMem) {
        std::printf("[!] VirtualAllocEx(stub) failed (err=%lu)\n", GetLastError());
        return false;
    }
    WriteProcessMemory(proc, stubMem, stub, sizeof(stub), nullptr);

    HANDLE thread = CreateRemoteThread(proc, nullptr, 0,
        (LPTHREAD_START_ROUTINE)stubMem, nullptr, 0, nullptr);
    if (!thread) {
        std::printf("[!] CreateRemoteThread(stub) failed (err=%lu)\n", GetLastError());
        return false;
    }
    WaitForSingleObject(thread, 15000);
    GetExitCodeThread(thread, &outExit);
    CloseHandle(thread);
    VirtualFreeEx(proc, stubMem, 0, MEM_RELEASE);

    std::printf("[+] Mapped DLL base=%p, DllMain exit=%lu\n", base, outExit);
    return true;
}

static bool LoadLibraryInject(HANDLE proc, const std::wstring& dllPath)
{
    size_t len = (wcslen(dllPath.c_str()) + 1) * sizeof(wchar_t);
    void* remote = VirtualAllocEx(proc, nullptr, len, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
    if (!remote) {
        std::printf("[!] VirtualAllocEx failed (err=%lu)\n", GetLastError());
        return false;
    }
    SIZE_T written = 0;
    if (!WriteProcessMemory(proc, remote, dllPath.c_str(), len, &written)) {
        std::printf("[!] WriteProcessMemory failed (err=%lu)\n", GetLastError());
        VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
        return false;
    }
    HMODULE k32 = GetModuleHandleA("kernel32.dll");
    FARPROC loadLib = GetProcAddress(k32, "LoadLibraryW");
    HANDLE thread = CreateRemoteThread(proc, nullptr, 0,
        (LPTHREAD_START_ROUTINE)loadLib, remote, 0, nullptr);
    if (!thread) {
        std::printf("[!] CreateRemoteThread failed (err=%lu)\n", GetLastError());
        VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
        return false;
    }
    WaitForSingleObject(thread, 15000);
    DWORD exitCode = 0;
    GetExitCodeThread(thread, &exitCode);
    CloseHandle(thread);
    VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
    if (exitCode == 0) {
        std::printf("[!] LoadLibrary returned 0 (DLL failed to load)\n");
        return false;
    }
    std::printf("[+] LoadLibrary returned %p\n", (void*)(uintptr_t)exitCode);
    return true;
}

int wmain(int argc, wchar_t** argv)
{
    std::wstring dllPath;
    std::wstring procName = L"SCPSL.exe";
    bool useManualMap = true;

    for (int i = 1; i < argc; i++) {
        if (wcscmp(argv[i], L"-l") == 0)
            useManualMap = false;
        else if (dllPath.empty())
            dllPath = argv[i];
        else
            procName = argv[i];
    }

    if (dllPath.empty()) {
        std::printf("=== SCP:SL Injector (x64, manual map) ===\n\n");
        std::wprintf(L"DLL path: ");
        wchar_t buf[1024];
        if (!_getws_s(buf, 1024))
            return 1;
        dllPath = buf;
        if (dllPath.empty())
            return 1;
    }

    DWORD pid = FindProcessByName(procName.c_str());
    if (!pid) {
        std::wprintf(L"[!] Process '%s' not found. Start the game first.\n", procName.c_str());
        std::printf("[ ] Press Enter to exit...\n");
        std::getchar();
        return 1;
    }

    std::wprintf(L"[i] Process found: PID=%lu (%s)\n", pid, procName.c_str());
    std::wprintf(L"[i] Method: %s\n", useManualMap ? L"manual map" : L"LoadLibrary");
    std::wprintf(L"[i] Injecting: %s\n", dllPath.c_str());

    HANDLE proc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!proc) {
        std::printf("[!] OpenProcess failed (err=%lu). Try running as administrator.\n", GetLastError());
        std::printf("[ ] Press Enter to exit...\n");
        std::getchar();
        return 1;
    }

    bool ok;
    if (useManualMap) {
        char narrow[1024] = {};
        WideCharToMultiByte(CP_UTF8, 0, dllPath.c_str(), -1, narrow, sizeof(narrow), nullptr, nullptr);
        DWORD exitCode = 0;
        ok = ManualMap(proc, narrow, exitCode);
        if (ok && exitCode == 0) {
            std::printf("[!] DllMain returned 0\n");
            ok = false;
        }
    } else {
        ok = LoadLibraryInject(proc, dllPath);
    }
    CloseHandle(proc);

    std::printf(ok ? "[+] Injection OK\n" : "[!] Injection failed\n");
    std::printf("[ ] Press Enter to exit...\n");
    std::getchar();
    return ok ? 0 : 1;
}
