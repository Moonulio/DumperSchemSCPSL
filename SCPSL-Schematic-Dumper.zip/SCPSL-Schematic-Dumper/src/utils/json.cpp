#include "json.h"
#include <cstdio>

namespace
{
    void EscapeString(std::string& out, const std::string& in)
    {
        out += '"';
        for (unsigned char c : in) {
            switch (c) {
                case '"':  out += "\\\""; break;
                case '\\': out += "\\\\"; break;
                case '\b': out += "\\b";  break;
                case '\f': out += "\\f";  break;
                case '\n': out += "\\n";  break;
                case '\r': out += "\\r";  break;
                case '\t': out += "\\t";  break;
                default:
                    if (c < 0x20) {
                        char buf[8];
                        std::snprintf(buf, sizeof(buf), "\\u%04x", c);
                        out += buf;
                    } else {
                        out += (char)c;
                    }
            }
        }
        out += '"';
    }
}

JsonWriter::JsonWriter(bool pretty)
    : pretty_(pretty)
{
}

void JsonWriter::ItemPrefix()
{
    // Called for a brand new item inside an array.
    if (!firstItem_)
        b_ += ',';
    if (pretty_)
        b_ += '\n';
    Indent();
    firstItem_ = false;
}

void JsonWriter::Indent()
{
    if (pretty_)
        b_.append((size_t)depth_ * 2, ' ');
}

void JsonWriter::BeginObject()
{
    if (expectValue_) {
        // value of a key: '{'
        b_ += '{';
        expectValue_ = false;
    } else {
        ItemPrefix();
        b_ += '{';
    }
    depth_++;
    firstItem_ = true;
}

void JsonWriter::EndObject()
{
    depth_--;
    if (!firstItem_) {
        if (pretty_)
            b_ += '\n';
        Indent();
    }
    b_ += '}';
    firstItem_ = false;
}

void JsonWriter::BeginArray()
{
    if (expectValue_) {
        b_ += '[';
        expectValue_ = false;
    } else {
        ItemPrefix();
        b_ += '[';
    }
    depth_++;
    firstItem_ = true;
}

void JsonWriter::EndArray()
{
    depth_--;
    if (!firstItem_) {
        if (pretty_)
            b_ += '\n';
        Indent();
    }
    b_ += ']';
    firstItem_ = false;
}

void JsonWriter::Key(const char* key)
{
    if (!firstItem_)
        b_ += ',';
    if (pretty_)
        b_ += '\n';
    Indent();
    std::string tmp;
    EscapeString(tmp, key ? key : "");
    b_ += tmp;
    b_ += ':';
    if (pretty_)
        b_ += ' ';
    firstItem_ = false;
    expectValue_ = true;
}

void JsonWriter::ValueString(const std::string& v)
{
    if (!expectValue_)
        ItemPrefix();
    std::string tmp;
    EscapeString(tmp, v);
    b_ += tmp;
    expectValue_ = false;
}

void JsonWriter::ValueInt(long long v)
{
    if (!expectValue_)
        ItemPrefix();
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%lld", v);
    b_ += buf;
    expectValue_ = false;
}

void JsonWriter::ValueDouble(double v, int decimals)
{
    if (!expectValue_)
        ItemPrefix();
    char buf[64];
    std::snprintf(buf, sizeof(buf), "%.*f", decimals, v);
    b_ += buf;
    expectValue_ = false;
}

void JsonWriter::ValueBool(bool v)
{
    if (!expectValue_)
        ItemPrefix();
    b_ += v ? "true" : "false";
    expectValue_ = false;
}
