#include <windows.h>
#include "sdk/il2cpp.h"
#include "sdk/scpsl.h"
#include "hooks/dx11hook.h"
#include "shutdown.h"

HMODULE g_hModule = nullptr;
static HANDLE g_mainThread = nullptr;
static volatile LONG g_shutdownRequested = 0;

void RequestMainThreadExit()
{
    InterlockedExchange(&g_shutdownRequested, 1);
}

void WaitForMainThreadExit()
{
    if (g_mainThread)
        WaitForSingleObject(g_mainThread, 5000);
}

static DWORD WINAPI MainThread(LPVOID)
{
    g_mainThread = GetCurrentThread();

    // Wait for the game's il2cpp runtime.
    while (!GetModuleHandleW(L"GameAssembly.dll"))
        Sleep(200);

    // Resolve the API and wait until the domain is ready.
    for (;;) {
        if (API::Initialize() && domain != nullptr)
            break;
        Sleep(250);
    }

    // Give the runtime time to finish registering assemblies/classes.
    Sleep(2000);

    // Wait for the game window (game is fully up in the main menu).
    while (!FindWindowW(nullptr, L"SCPSL"))
        Sleep(250);

    // Resolve game classes (retries until the core classes are found).
    while (!SCPSL::Init())
        Sleep(500);

    // Set up the D3D11 present hook (retries until the swapchain is available).
    while (!DX11Hook::Initialize())
        Sleep(500);

    for (;;) {
        if (g_shutdownRequested)
            break;
        Sleep(1000);
    }

    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
    if (ul_reason_for_call == DLL_PROCESS_ATTACH) {
        g_hModule = hModule;
        DisableThreadLibraryCalls(hModule);
        CreateThread(nullptr, 0, MainThread, hModule, 0, nullptr);
    }
    return TRUE;
}
