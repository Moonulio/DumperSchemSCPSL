#pragma once

#include <windows.h>
#include <cstdint>
#include <cstddef>
#include <cstring>

// ---------------------------------------------------------------------------
// Minimal il2cpp definitions. Only the struct layouts that are stable across
// Unity 2021.x / 2022.x are defined here; everything else is resolved through
// the exported functions of GameAssembly.dll at runtime (no hardcoded offsets).
// ---------------------------------------------------------------------------

struct Il2CppDomain;
struct Il2CppAssembly;
struct Il2CppImage;
struct Il2CppClass;
struct Il2CppType;
struct Il2CppField;
struct Il2CppReflectionMethod;
struct Il2CppException;

struct Il2CppObject {
    void* vtable;
    void* monitor;
};

struct Il2CppArrayBounds {
    uintptr_t length;
    int32_t   lower_bound;
};

struct Il2CppArray {
    Il2CppObject         object;    // 16 bytes
    Il2CppArrayBounds*   bounds;    // 8 bytes
    uint64_t             max_length;// 8 bytes
    // data follows
};

struct Il2CppString {
    Il2CppObject object;            // 16 bytes
    int32_t      length;
    wchar_t      chars[1];
};

// MethodInfo is intentionally opaque: we only pass it to il2cpp_runtime_invoke.
struct MethodInfo;

// Domain handle used across the whole mod (matches the snippet's `domain` global).
extern Il2CppDomain* domain;

namespace API
{
    // Resolved function pointers -------------------------------------------------
    inline HMODULE gameAssembly = nullptr;

    inline Il2CppDomain*   (*il2cpp_domain_get)() = nullptr;
    inline void*           (*il2cpp_thread_attach)(Il2CppDomain*) = nullptr;
    inline const Il2CppAssembly** (*il2cpp_domain_get_assemblies)(Il2CppDomain*, size_t*) = nullptr;
    inline Il2CppImage*    (*il2cpp_assembly_get_image)(const Il2CppAssembly*) = nullptr;
    inline const char*     (*il2cpp_image_get_name)(Il2CppImage*) = nullptr;
    inline Il2CppClass*    (*il2cpp_class_from_name)(Il2CppImage*, const char*, const char*) = nullptr;
    inline const MethodInfo* (*il2cpp_class_get_method_from_name)(Il2CppClass*, const char*, int) = nullptr;
    inline void*           (*il2cpp_runtime_invoke)(const MethodInfo*, void*, void**, void**) = nullptr;
    inline void*           (*il2cpp_object_unbox)(Il2CppObject*) = nullptr;
    inline Il2CppObject*   (*il2cpp_object_new)(Il2CppClass*) = nullptr;
    inline Il2CppType*     (*il2cpp_class_get_type)(Il2CppClass*) = nullptr;
    inline Il2CppObject*   (*il2cpp_type_get_object)(const Il2CppType*) = nullptr;
    inline Il2CppClass*    (*il2cpp_object_get_class)(Il2CppObject*) = nullptr;
    inline const char*     (*il2cpp_class_get_name)(Il2CppClass*) = nullptr;
    inline const char*     (*il2cpp_class_get_namespace)(Il2CppClass*) = nullptr;
    inline Il2CppClass*    (*il2cpp_class_get_parent)(Il2CppClass*) = nullptr;
    inline int             (*il2cpp_class_is_valuetype)(Il2CppClass*) = nullptr;
    inline Il2CppField*    (*il2cpp_class_get_field_from_name)(Il2CppClass*, const char*) = nullptr;
    inline const char*     (*il2cpp_field_get_name)(Il2CppField*) = nullptr;
    inline uint32_t        (*il2cpp_field_get_offset)(Il2CppField*) = nullptr;
    inline Il2CppType*     (*il2cpp_field_get_type)(Il2CppField*) = nullptr;
    inline void            (*il2cpp_field_get_value)(Il2CppObject*, Il2CppField*, void*) = nullptr;
    inline void            (*il2cpp_field_static_get_value)(Il2CppField*, void*) = nullptr;
    inline Il2CppClass*    (*il2cpp_class_from_type)(const Il2CppType*) = nullptr;
    inline Il2CppClass*    (*il2cpp_array_class_get)(Il2CppClass*, size_t) = nullptr;
    inline size_t          (*il2cpp_class_get_size)(Il2CppClass*) = nullptr;
    inline Il2CppString*   (*il2cpp_string_new)(const char*) = nullptr;
    inline size_t          (*il2cpp_image_get_class_count)(Il2CppImage*) = nullptr;
    inline Il2CppClass*    (*il2cpp_image_get_class)(Il2CppImage*, size_t) = nullptr;
    inline Il2CppField*    (*il2cpp_class_get_fields)(Il2CppClass*, void**) = nullptr;

    // Initializes the bridge. Must be called after GameAssembly.dll is loaded.
    bool Initialize();

    // Locates an assembly image by name (exact match).
    Il2CppImage* FindImage(const char* assemblyName);

    // Locates a class by (assembly, namespace, classname).
    Il2CppClass* FindClass(const char* assemblyName, const char* ns, const char* name);

    // Locates a method. searchParents walks the class hierarchy.
    const MethodInfo* FindMethod(Il2CppClass* klass, const char* name, int argc, bool searchParents);

    // Locates a field (walks the class hierarchy).
    Il2CppField* FindField(Il2CppClass* klass, const char* name);
    int32_t      FindFieldOffset(Il2CppClass* klass, const char* name);

    // Reads an instance field directly from the object (fast path).
    template <typename T>
    T ReadInstanceField(Il2CppClass* klass, void* obj, const char* name, T def = {}) {
        int32_t off = FindFieldOffset(klass, name);
        if (off < 0 || !obj) return def;
        return *(T*)((uint8_t*)obj + off);
    }

    // Reads a static field.
    template <typename T>
    T ReadStaticField(Il2CppClass* klass, const char* name, T def = {}) {
        Il2CppField* f = FindField(klass, name);
        if (!f) return def;
        T v{};
        il2cpp_field_static_get_value(f, &v);
        return v;
    }
}

// Helper: pointer to element `index` of an il2cpp array.
template <typename T>
inline T* ArrayElement(Il2CppArray* arr, uint64_t index) {
    if (!arr || index >= arr->max_length) return nullptr;
    return (T*)((uint8_t*)arr + sizeof(Il2CppArray) + index * sizeof(T));
}
