#pragma once

#include <windows.h>

extern HMODULE g_hModule;
void RequestMainThreadExit();
void WaitForMainThreadExit();
